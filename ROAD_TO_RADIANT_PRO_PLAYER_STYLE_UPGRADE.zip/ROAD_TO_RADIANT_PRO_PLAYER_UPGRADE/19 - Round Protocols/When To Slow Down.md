# When To Slow Down

## Principle

Slow after first pick, after enemy utility dump, when spike is unsafe, or when enemy wants you to rush.

## Trigger

Use this protocol when the round state matches the title. Call it early so teammates understand the next action.

## Do

- Communicate the round state.
- Protect spike or key weapon.
- Take fights with trade structure.
- Use utility to isolate one angle or delay enemy timing.
- Reset after the objective is achieved.

## Do Not

- Overheat after one kill.
- Give isolated duels.
- Rotate without info.
- Use all utility before the real fight.
- Play for clips over conversion.

## Comms

```txt
We are in When To Slow Down. Slow and trade.
I have utility for the next contact.
Do not fight alone.
Play spike/time/numbers.
```

## Review Table

| Date | Map | Round | Did I follow protocol? | Correction |
|---|---|---:|---|---|
|  |  |  |  |  |
