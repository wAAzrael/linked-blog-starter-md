# Round Protocols Dashboard

Protocols are automatic decisions for common round states. Use them so you do not invent a new brain every round.

## Protocol Index

- [[19 - Round Protocols/5v4 Man Advantage]]
- [[19 - Round Protocols/4v5 Man Disadvantage]]
- [[19 - Round Protocols/Anti-Eco Rules]]
- [[19 - Round Protocols/Eco Round Rules]]
- [[19 - Round Protocols/Bonus Round Rules]]
- [[19 - Round Protocols/Post-Plant Rules]]
- [[19 - Round Protocols/Retake Rules]]
- [[19 - Round Protocols/Clutch Protocol]]
- [[19 - Round Protocols/Save Rules]]
- [[19 - Round Protocols/Contact Explode Rules]]
- [[19 - Round Protocols/Fake Rules]]
- [[19 - Round Protocols/Lurk Punish Rules]]
- [[19 - Round Protocols/When To Slow Down]]
- [[19 - Round Protocols/When To Speed Up]]

## Core Rule

Do not ask “what do I feel like doing?” Ask “what protocol is this round state asking for?”
