# Matchup Dashboard

## How to use

By round 5, identify the enemy style and open the matching page.

## Matchups

- [[16 - Matchup Library/Vs Fast Rush Teams]]
- [[16 - Matchup Library/Vs Slow Default Teams]]
- [[16 - Matchup Library/Vs Double Duelist]]
- [[16 - Matchup Library/Vs Heavy Sentinel]]
- [[16 - Matchup Library/Vs Operator Player]]
- [[16 - Matchup Library/Vs Lurk Heavy Teams]]
- [[16 - Matchup Library/Vs No Sentinel]]
- [[16 - Matchup Library/Vs Aggressive Controllers]]

## Pattern Callout

```txt
They are playing: fast / slow / lurk-heavy / OP-heavy / sentinel-heavy.
Punish with:
Next round plan:
```
