# Vs Double Duelist

## Signs

- Repeated round structure.
- Similar first contact timing.
- Similar utility usage.
- Same player taking same space.

## Punish

- Expect explosive contact, punish first movement ability with layered utility, avoid solo anchor deaths.

## Controller Plan

- Change smoke timing.
- Deny their preferred info path.
- Preserve one utility piece for the real hit.
- Call the counter before buy phase ends.

## Reyna Plan

- Take fights only when enemy pattern creates isolated duels.
- Leer for team timing, not solo ego.
- Dismiss out after pick and convert numbers.

## Chamber Plan

- Trap the timing they rely on.
- Hold the first-contact angle once, then move.
- Use Rendezvous to punish predictable pressure without dying.

## Review Log

| Date | Map | Enemy pattern | Counter used | Result |
|---|---|---|---|---|
|  |  |  |  |  |
