# Vs Fast Rush Teams

## Signs

- Repeated round structure.
- Similar first contact timing.
- Similar utility usage.
- Same player taking same space.

## Punish

- Use early delay utility, keep smoke until contact, play crossfires, stack after repeated pattern, punish with judge/shorty only if economy supports it.

## Controller Plan

- Change smoke timing.
- Deny their preferred info path.
- Preserve one utility piece for the real hit.
- Call the counter before buy phase ends.

## Reyna Plan

- Take fights only when enemy pattern creates isolated duels.
- Leer for team timing, not solo ego.
- Dismiss out after pick and convert numbers.

## Chamber Plan

- Trap the timing they rely on.
- Hold the first-contact angle once, then move.
- Use Rendezvous to punish predictable pressure without dying.

## Review Log

| Date | Map | Enemy pattern | Counter used | Result |
|---|---|---|---|---|
|  |  |  |  |  |
