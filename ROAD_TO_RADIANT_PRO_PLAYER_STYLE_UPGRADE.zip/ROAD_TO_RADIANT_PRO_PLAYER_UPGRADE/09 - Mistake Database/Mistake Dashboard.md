# Mistake Dashboard

## Categories

- [[09 - Mistake Database/Mechanics Mistakes]]
- [[09 - Mistake Database/Positioning Mistakes]]
- [[09 - Mistake Database/Utility Mistakes]]
- [[09 - Mistake Database/Decision-Making Mistakes]]
- [[09 - Mistake Database/Communication Mistakes]]
- [[09 - Mistake Database/Mental Mistakes]]

## Mistake Quality Standard

Bad note:
```txt
I played bad.
```

Good note:
```txt
Round 8 Ascent defense: rotated from B on one A Main sound, B hit came late. Correction: rotate only on spike/3+ bodies/key utility; call what I give up.
```

## Repeated Mistake Tracker

| Mistake | Times this week | Trigger | Correction |
|---|---:|---|---|
|  |  |  |  |
