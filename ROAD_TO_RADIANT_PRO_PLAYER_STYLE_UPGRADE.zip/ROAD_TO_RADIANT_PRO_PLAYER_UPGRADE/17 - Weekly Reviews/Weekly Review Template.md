# Weekly Review

## Week

```txt
Dates:
Start rank/RR:
End rank/RR:
Peak rank/RR:
Games played:
Record:
```

## Best Performing

| Category | Answer | Why |
|---|---|---|
| Best map |  |  |
| Worst map |  |  |
| Best agent |  |  |
| Worst agent |  |  |
| Best mechanic |  |  |
| Weakest decision |  |  |

## Repeated Mistake

```txt
Main repeated mistake:
Trigger:
Why it happens:
Correction for next week:
```

## Do More / Do Less

| Do More | Do Less |
|---|---|
|  |  |
|  |  |
|  |  |

## Next Week Focus

1. 
2. 
3.
