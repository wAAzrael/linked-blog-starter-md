# Weekly Review Dashboard

## Review Pages

- [[17 - Weekly Reviews/Weekly Review Template]]
- [[17 - Weekly Reviews/Monthly Review Template]]

## Weekly Rule

One week = one main correction.

If you try to fix ten things, you fix nothing.
