# Monthly Review

## Rank Progress

| Start | End | Peak | Notes |
|---|---|---|---|
|  |  |  |  |

## Biggest Improvement

-

## Biggest Leak

-

## Agent Pool Changes

-

## Map Pool Confidence

| Map | Confidence /10 | Main work needed |
|---|---:|---|
| Ascent |  |  |
| Breeze |  |  |
| Haven |  |  |
| Lotus |  |  |
| Split |  |  |
| Sunset |  |  |
| Summit |  |  |

## Next Month System

```txt
Main climb focus:
Main mechanics focus:
Main agent focus:
Main map focus:
Queue rule:
```
