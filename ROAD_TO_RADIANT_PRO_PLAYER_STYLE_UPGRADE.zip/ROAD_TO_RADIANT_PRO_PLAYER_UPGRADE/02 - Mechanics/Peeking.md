---
type: mechanics
status: active
updated: 2026-07-04
---
# Peeking

## Pro Standard

The goal is not flashy aim. The goal is repeatable fight quality under pressure.

## Rules

- Peek for info with escape route
- Peek for kill only with crosshair and timing advantage
- Never repeek the same angle with same rhythm
- Use jiggle to bait OP/utility
- Swing off teammate contact when possible

## Review Questions

- Did I know where the enemy could be before I peeked?
- Was my crosshair already close to the target?
- Did I stop before shooting?
- Did I have a trade or escape route?
- Was the fight necessary for the round win condition?

## Drill

```txt
10 minutes focused DM:
- 3 min crosshair height only
- 3 min burst reset only
- 2 min no crouch
- 2 min fight selection / do not take bad duels
```

## Mistake Log

| Date | Map | Situation | Mechanical issue | Correction |
|---|---|---|---|---|
|  |  |  |  |  |
