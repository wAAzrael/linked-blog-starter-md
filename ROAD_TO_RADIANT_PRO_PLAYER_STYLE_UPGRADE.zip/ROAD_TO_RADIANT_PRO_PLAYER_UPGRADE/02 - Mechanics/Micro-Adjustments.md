---
type: mechanics
status: active
updated: 2026-07-04
---
# Micro-Adjustments

## Pro Standard

The goal is not flashy aim. The goal is repeatable fight quality under pressure.

## Rules

- Aim correction should be small and calm
- If corrections are huge, pre-aim was wrong
- Train under movement pressure, not only static bots
- Do not overflick close fights
- Keep grip/arm tension consistent

## Review Questions

- Did I know where the enemy could be before I peeked?
- Was my crosshair already close to the target?
- Did I stop before shooting?
- Did I have a trade or escape route?
- Was the fight necessary for the round win condition?

## Drill

```txt
10 minutes focused DM:
- 3 min crosshair height only
- 3 min burst reset only
- 2 min no crouch
- 2 min fight selection / do not take bad duels
```

## Mistake Log

| Date | Map | Situation | Mechanical issue | Correction |
|---|---|---|---|---|
|  |  |  |  |  |
