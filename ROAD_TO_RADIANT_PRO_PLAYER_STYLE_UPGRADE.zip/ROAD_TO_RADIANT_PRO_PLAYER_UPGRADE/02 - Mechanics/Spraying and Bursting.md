---
type: mechanics
status: active
updated: 2026-07-04
---
# Spraying and Bursting

## Pro Standard

The goal is not flashy aim. The goal is repeatable fight quality under pressure.

## Rules

- Default to 2-4 bullet bursts at mid/long range
- Spray only close range or through smoke/wall with info
- After bad first burst, strafe reset before next burst
- Crouch spray only as a deliberate commit
- Track panic sprays in mistake database

## Review Questions

- Did I know where the enemy could be before I peeked?
- Was my crosshair already close to the target?
- Did I stop before shooting?
- Did I have a trade or escape route?
- Was the fight necessary for the round win condition?

## Drill

```txt
10 minutes focused DM:
- 3 min crosshair height only
- 3 min burst reset only
- 2 min no crouch
- 2 min fight selection / do not take bad duels
```

## Mistake Log

| Date | Map | Situation | Mechanical issue | Correction |
|---|---|---|---|---|
|  |  |  |  |  |
