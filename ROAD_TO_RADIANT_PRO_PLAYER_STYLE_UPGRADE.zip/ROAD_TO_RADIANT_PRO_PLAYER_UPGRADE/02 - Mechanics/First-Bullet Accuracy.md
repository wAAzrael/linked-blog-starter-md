---
type: mechanics
status: active
updated: 2026-07-04
---
# First-Bullet Accuracy

## Pro Standard

The goal is not flashy aim. The goal is repeatable fight quality under pressure.

## Rules

- Crosshair already on likely head before key press
- Shoot only after movement is fully stopped
- Prefer one clean bullet over panic spray
- Reset after miss instead of dragging forever
- Practice with sheriff/guardian style discipline

## Review Questions

- Did I know where the enemy could be before I peeked?
- Was my crosshair already close to the target?
- Did I stop before shooting?
- Did I have a trade or escape route?
- Was the fight necessary for the round win condition?

## Drill

```txt
10 minutes focused DM:
- 3 min crosshair height only
- 3 min burst reset only
- 2 min no crouch
- 2 min fight selection / do not take bad duels
```

## Mistake Log

| Date | Map | Situation | Mechanical issue | Correction |
|---|---|---|---|---|
|  |  |  |  |  |
