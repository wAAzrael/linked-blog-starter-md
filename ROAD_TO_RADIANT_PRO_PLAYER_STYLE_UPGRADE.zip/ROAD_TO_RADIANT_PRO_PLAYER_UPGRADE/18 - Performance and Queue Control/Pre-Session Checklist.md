# Pre-Session Checklist

## Purpose

Use this before ranked to decide if you are ready to queue.

## Checklist

| Item | Status |
|---|---|
| Energy /10 |  |
| Mental /10 |  |
| Aim confidence /10 |  |
| Main focus known |  |
| Stop-loss known |  |

## Rules

- If focus is below 5/10, warm up or review instead of ranked.
- If you are angry from the last game, wait before queueing.
- If you cannot explain your last loss objectively, you are probably emotional.
- If hands feel bad, lower expectations and focus on decision quality.

## Notes

| Date | Situation | Decision | Result |
|---|---|---|---|
|  |  |  |  |
