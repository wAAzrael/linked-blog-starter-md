# Queue Control Dashboard

## Pages

- [[18 - Performance and Queue Control/Pre-Session Checklist]]
- [[18 - Performance and Queue Control/When Not To Queue]]
- [[18 - Performance and Queue Control/Tilt Rules]]
- [[18 - Performance and Queue Control/Bad Day Rules]]
- [[18 - Performance and Queue Control/Energy Tracker]]
- [[18 - Performance and Queue Control/Post-Session Reset]]

## Stop-Loss

Default ranked stop-loss:
- 3 losses in a block, or
- 2 games where you repeat the exact same mistake, or
- 1 game where you are clearly tilted and cannot reset.

## Queue Question

```txt
Am I queueing to improve or to recover emotion?
```
