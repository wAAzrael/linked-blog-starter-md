# Pro VOD Deconstruction Template

## VOD Info

```txt
Player:
Agent:
Map:
Match:
Round:
```

## Before Round Prediction

- What is the round goal?
- What is the first 20 seconds setup?
- What utility must be preserved?

## Observed

| Timestamp | Action | Why it matters |
|---|---|---|
|  |  |  |

## Concept To Steal

-

## How I Apply It In Ranked

-
