# Question Bank

## Controller Questions

- Why did the controller smoke now instead of earlier?
- What did the smoke deny?
- Was the controller alive for second cycle?
- Which teammate played off the utility?

## Duelist Questions

- Was first contact traded?
- Did the entry create space or just chase kill?
- What made the fight favorable?

## Sentinel/Flex Questions

- What timing did the trap cover?
- When did the player rotate?
- Did the lurk create value or isolate from team?

## Macro Questions

- What was the win condition?
- What info changed the round?
- What protocol did they follow after first pick/death?
