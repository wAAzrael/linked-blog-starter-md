# Clip Tagging System

Use tags so your clips become searchable.

## Tags

```txt
#mechanics
#utility
#smoke_timing
#retake
#postplant
#man_advantage
#man_disadvantage
#tilt
#first_death
#clutch
#midround
#agent_omen
#agent_astra
#agent_clove
#agent_reyna
#agent_chamber
#map_ascent
#map_breeze
#map_haven
#map_lotus
#map_split
#map_sunset
#map_summit
```

## Clip Note Template

```txt
Clip link:
Map:
Agent:
Round:
Tag:
What happened:
Why it happened:
Correction:
```
