# How To VOD Like A Pro

## One-Round Method

Pause before barriers drop and answer:

1. What is the comp trying to do?
2. What is the controller's first job?
3. Who owns first contact?
4. What utility is saved for second contact?
5. What would make this round fail?

Then watch the round and compare.

## What To Steal

- Smoke timing
- First 20 seconds pathing
- How they react to first pick/death
- Post-plant spacing
- Retake grouping
- Comms simplicity

## What Not To Copy Blindly

- Team-specific set plays you cannot coordinate.
- Utility that requires exact teammate timing.
- Risky pro fights without understanding why they work.
