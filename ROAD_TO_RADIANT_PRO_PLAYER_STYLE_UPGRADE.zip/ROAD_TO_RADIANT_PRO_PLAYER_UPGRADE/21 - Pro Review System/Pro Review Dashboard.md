# Pro Review Dashboard

## Review Types

- [[23 - Pro Player Style Lab/Pro Player Style Lab Dashboard|Pro Player Style Lab]]

- [[21 - Pro Review System/How To VOD Like A Pro]]
- [[21 - Pro Review System/Clip Tagging System]]
- [[21 - Pro Review System/Pro VOD Deconstruction Template]]
- [[21 - Pro Review System/Question Bank]]

## Rule

Do not watch pro VOD for entertainment only. Watch one round, steal one concept, apply it in ranked.
