# Summit Enemy Patterns

Linked map: [[06 - Maps/Map Pool/Summit]]

## Common Pattern Log

| Date | Enemy comp | Pattern | Counter | Result |
|---|---|---|---|---|
|  |  |  |  |  |

## What To Watch On Summit

- Lane 1 / outer pressure
- Lane 2 / mid pressure
- Lane 3 / opposite outer pressure
- Droppable wall zones
- Site choke 1
- Site choke 2
- Retake corridors
- Spawn rotation path

## Anti-Strat Questions

- Who takes first contact every round?
- Which site/area do they avoid?
- Does the sentinel anchor rotate or stay?
- Does the controller smoke instantly or reactively?
- What happens after they lose first pick?
