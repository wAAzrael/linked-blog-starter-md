# Lotus Enemy Patterns

Linked map: [[06 - Maps/Map Pool/Lotus]]

## Common Pattern Log

| Date | Enemy comp | Pattern | Counter | Result |
|---|---|---|---|---|
|  |  |  |  |  |

## What To Watch On Lotus

- A Main
- A Rubble
- A Tree/Door
- B Main
- C Main
- C Bend
- Rotating Door
- Defender Spawn

## Anti-Strat Questions

- Who takes first contact every round?
- Which site/area do they avoid?
- Does the sentinel anchor rotate or stay?
- Does the controller smoke instantly or reactively?
- What happens after they lose first pick?
