# Breeze Enemy Patterns

Linked map: [[06 - Maps/Map Pool/Breeze]]

## Common Pattern Log

| Date | Enemy comp | Pattern | Counter | Result |
|---|---|---|---|---|
|  |  |  |  |  |

## What To Watch On Breeze

- A Main
- Cave
- Pyramids
- Mid Nest
- Tube
- Hall
- B Main
- Elbow

## Anti-Strat Questions

- Who takes first contact every round?
- Which site/area do they avoid?
- Does the sentinel anchor rotate or stay?
- Does the controller smoke instantly or reactively?
- What happens after they lose first pick?
