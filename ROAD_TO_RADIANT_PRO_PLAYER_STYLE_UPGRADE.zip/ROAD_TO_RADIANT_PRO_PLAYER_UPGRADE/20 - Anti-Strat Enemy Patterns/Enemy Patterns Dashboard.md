# Enemy Patterns Dashboard

## Purpose

This folder is where ranked stops feeling random. Every enemy team repeats something.

## Pattern Types

- Fast rush
- Slow default
- Lurk heavy
- OP heavy
- Sentinel anchor heavy
- Retake heavy
- Over-rotate
- Never rotate
- Utility dump early

## Map Pattern Sheets

- [[20 - Anti-Strat Enemy Patterns/Ascent Enemy Patterns]]
- [[20 - Anti-Strat Enemy Patterns/Breeze Enemy Patterns]]
- [[20 - Anti-Strat Enemy Patterns/Haven Enemy Patterns]]
- [[20 - Anti-Strat Enemy Patterns/Lotus Enemy Patterns]]
- [[20 - Anti-Strat Enemy Patterns/Split Enemy Patterns]]
- [[20 - Anti-Strat Enemy Patterns/Sunset Enemy Patterns]]
- [[20 - Anti-Strat Enemy Patterns/Summit Enemy Patterns]]
