# Common Ranked Patterns

| Pattern | Sign | Punish |
|---|---|---|
| Insta rush | 4-5 players contact same choke early | Delay utility, crossfire, stack after repeat |
| Contact explode | They walk then burst after first sound | Jiggle info, save utility, fight grouped |
| Fake heavy | Utility one site, spike ends other | Do not rotate without spike/multiple bodies |
| Lurk every round | Same player late mid/flank | Trap/hold, punish with late re-clear |
| OP anchor | Same angle early | Smoke, jiggle, force retake |
| No flank control | Enemy groups five | Late lurk or push extremity with teammate |
