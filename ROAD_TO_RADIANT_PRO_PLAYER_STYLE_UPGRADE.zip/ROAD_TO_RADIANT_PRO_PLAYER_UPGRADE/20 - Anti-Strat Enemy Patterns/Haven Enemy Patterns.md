# Haven Enemy Patterns

Linked map: [[06 - Maps/Map Pool/Haven]]

## Common Pattern Log

| Date | Enemy comp | Pattern | Counter | Result |
|---|---|---|---|---|
|  |  |  |  |  |

## What To Watch On Haven

- A Long
- A Short
- B Main
- Garage
- C Long
- C Cubby
- Defender Spawn
- Window

## Anti-Strat Questions

- Who takes first contact every round?
- Which site/area do they avoid?
- Does the sentinel anchor rotate or stay?
- Does the controller smoke instantly or reactively?
- What happens after they lose first pick?
