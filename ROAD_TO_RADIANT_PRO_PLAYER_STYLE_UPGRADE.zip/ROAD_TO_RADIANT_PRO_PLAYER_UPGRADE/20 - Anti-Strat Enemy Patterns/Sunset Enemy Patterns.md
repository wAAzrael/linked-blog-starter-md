# Sunset Enemy Patterns

Linked map: [[06 - Maps/Map Pool/Sunset]]

## Common Pattern Log

| Date | Enemy comp | Pattern | Counter | Result |
|---|---|---|---|---|
|  |  |  |  |  |

## What To Watch On Sunset

- B Main
- Market
- Mid Tiles
- Top Mid
- A Main
- A Elbow
- Defender Spawn
- Boba

## Anti-Strat Questions

- Who takes first contact every round?
- Which site/area do they avoid?
- Does the sentinel anchor rotate or stay?
- Does the controller smoke instantly or reactively?
- What happens after they lose first pick?
