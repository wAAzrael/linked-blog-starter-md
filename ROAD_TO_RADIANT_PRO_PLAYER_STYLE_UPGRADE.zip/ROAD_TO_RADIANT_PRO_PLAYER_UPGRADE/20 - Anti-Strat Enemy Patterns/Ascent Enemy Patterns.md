# Ascent Enemy Patterns

Linked map: [[06 - Maps/Map Pool/Ascent]]

## Common Pattern Log

| Date | Enemy comp | Pattern | Counter | Result |
|---|---|---|---|---|
|  |  |  |  |  |

## What To Watch On Ascent

- Top Mid
- Tiles
- Catwalk
- Tree
- A Main
- B Main
- Market
- Boat House

## Anti-Strat Questions

- Who takes first contact every round?
- Which site/area do they avoid?
- Does the sentinel anchor rotate or stay?
- Does the controller smoke instantly or reactively?
- What happens after they lose first pick?
