# Aim Dashboard

## Aim Identity

Your goal is **ranked-transfer aim**, not leaderboard-only aim.

Ranked-transfer aim means:
- clean first bullet under pressure,
- stable crosshair placement while thinking,
- calm micro-adjustments,
- disciplined burst resets,
- fight selection that respects utility and numbers.

## Weekly Aim Split

| Day | Main Focus | Notes |
|---|---|---|
| Monday | First-bullet + micro |  |
| Tuesday | Mid-range burst |  |
| Wednesday | Movement shooting |  |
| Thursday | Long-range discipline |  |
| Friday | DM transfer |  |
| Saturday | VOD + weak point |  |
| Sunday | Light maintenance |  |

## Benchmarks To Track

| Metric | Current | Target | Notes |
|---|---:|---:|---|
| DM calmness /10 |  |  |  |
| First-bullet confidence /10 |  |  |  |
| Panic spray deaths |  |  |  |
| Bad duel deaths |  |  |  |
| Focus quality /10 |  |  |  |
