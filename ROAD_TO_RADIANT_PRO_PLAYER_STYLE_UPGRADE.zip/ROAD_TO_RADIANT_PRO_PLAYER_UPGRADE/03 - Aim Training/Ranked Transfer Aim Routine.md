# Ranked Transfer Aim Routine

## 25-Minute Version

### 1. Range - 5 min
- 2 min bots, no movement, first bullet only.
- 2 min strafe-stop-shoot.
- 1 min sheriff/guardian calm taps.

### 2. Deathmatch - 12 min
Rules:
- No crouch for first half.
- Burst reset after every missed first burst.
- Do not chase spawns.
- Clear angles like a ranked round.

### 3. Map Custom - 5 min
Pick today’s map and walk through:
- common head heights,
- first contact angles,
- smoke crossing routes,
- post-plant positions.

### 4. Queue Readiness - 3 min
Answer:
- Are my hands warm?
- Am I calm?
- What is my one focus?

## Do Not Warm Up Forever

Warmup should prepare you to queue. It should not become avoidance.
