# Clove Map Pool Cheat Sheet

Linked main page: [[05 - Roles and Agents/Clove/Clove Playbook]]

| Map | Job |
|---|---|
| Ascent | Ruse Heaven/Tree or Market/CT with tempo. Meddle close pockets before contact. Ult only when team can trade revive. |
| Breeze | Fight with team through smokes; Meddle common close pockets. Keep Ruse for re-clear or plant safety. |
| Haven | Tempo controller for ranked; smoke isolated site, fight second wave, use ult for plant/retake trades. |
| Lotus | Fast tempo hits; Meddle close Lotus pockets and Ruse to isolate door/CT retakes. |
| Split | Fast Ruse through chokes, Meddle close corners. Great if you fight with first/second contact and still have post-death smoke value. |
| Sunset | Ruse B Market/CT, Meddle tight B Main or A Main pockets. Post-death smoke is useful in messy ranked retakes. |
| Summit | Great for early ranked adaptation: Ruse the most dangerous wall gap, Meddle close fights, and keep fighting with trade protocol. |

## Review Rule

After every Clove game, log one thing:

```txt
Was my agent pick valuable because of utility, space, picks, or tempo?
```
