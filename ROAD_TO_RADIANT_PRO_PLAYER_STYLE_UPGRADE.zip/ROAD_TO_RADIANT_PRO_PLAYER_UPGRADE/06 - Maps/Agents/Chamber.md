# Chamber Map Pool Cheat Sheet

Linked main page: [[05 - Roles and Agents/Chamber/Chamber Playbook]]

| Map | Job |
|---|---|
| Ascent | Rendezvous for A Main/B Main early pick or Market OP timing; Trademark Cat/B Main flank depending on default. |
| Breeze | OP/value rifle angles with Rendezvous. Trademark lurk/flank because rotations are long and late lurks decide rounds. |
| Haven | Trademark Garage/flank. Rendezvous for C Long/A Long opening pick and safe anchor escape. |
| Lotus | Trap flank/door timings. Rendezvous enables A/C extremity pick and safe fall back. |
| Split | Rendezvous for Ramp/B Main pick; Trademark flank/Mid. OP angles are strong but must reposition after first shot. |
| Sunset | Trademark Mid/B flank. Rendezvous for B Main or A Main pick, then fall into retake/setup. |
| Summit | Trademark the most common wall-change flank. Rendezvous lets you test aggressive angles safely while learning the map. |

## Review Rule

After every Chamber game, log one thing:

```txt
Was my agent pick valuable because of utility, space, picks, or tempo?
```
