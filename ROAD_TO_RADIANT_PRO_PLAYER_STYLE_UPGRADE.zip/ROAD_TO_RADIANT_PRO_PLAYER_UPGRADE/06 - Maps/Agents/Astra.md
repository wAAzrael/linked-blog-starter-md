# Astra Map Pool Cheat Sheet

Linked main page: [[05 - Roles and Agents/Astra/Astra Playbook]]

| Map | Job |
|---|---|
| Ascent | Star Mid choke, Tree, Market/Lane. Use recalls to fake presence, pull default plant or defuse, stun Tree/Market swings. |
| Breeze | Global stars slow extremes; pull/stun plant zones and choke re-swings. Recall early star to fake map pressure. |
| Haven | Stars across three sites for global slow. Pull A default/C plant, stun Garage/B entries, recall to fake rotations. |
| Lotus | Excellent: stars for A Rubble, C Main, B choke, plant/defuse. Recalls create fake door pressure. |
| Split | Stars for Mid choke, Ramps, Heaven, plant spots. Pulls/stuns punish narrow chokepoint swings. |
| Sunset | Star B Main/Market/Mid. Pull default plant/defuse and stun Market swings. |
| Summit | Global stars are ideal for wall-state chaos: place stars on common wall gaps, plant zones, and retake paths; recall to fake a wall-side hit. |

## Review Rule

After every Astra game, log one thing:

```txt
Was my agent pick valuable because of utility, space, picks, or tempo?
```
