# Omen Map Pool Cheat Sheet

Linked main page: [[05 - Roles and Agents/Omen/Omen Playbook]]

| Map | Job |
|---|---|
| Ascent | Delay Top Mid smoke until Mid players are ready; Paranoia A Main/Tree or B Lane; save a smoke for post-plant or retake. |
| Breeze | Smoke cross angles and use Paranoia for grouped entries. Do not waste both smokes before spike crosses the danger line. |
| Haven | Smoke A Heaven/CT, Garage/Window control, Paranoia A Short/Garage/C entry. TP after contact for off-angles. |
| Lotus | Paranoia through tight lanes/door areas, smoke Heaven/CT-style lines, TP into off-angle only after teammates force eyes away. |
| Split | Smoke Mid/Vent/Mail, Paranoia through A Main/B Main tight lanes. One-way-style smokes are high value if rehearsed. |
| Sunset | Smoke Market/CT or A Heaven/Link, Paranoia B Main/Market crunch. Use TP only after utility breaks crosshair placement. |
| Summit | Use smokes to isolate new wall gaps. Paranoia through compressed wall-created corridors. Verify one-ways before adding them to the live library. |

## Review Rule

After every Omen game, log one thing:

```txt
Was my agent pick valuable because of utility, space, picks, or tempo?
```
