# Reyna Map Pool Cheat Sheet

Linked main page: [[05 - Roles and Agents/Reyna/Reyna Playbook]]

| Map | Job |
|---|---|
| Ascent | Leer for Mid/Cat or A Main entry; Dismiss back into traded space, not deeper into site alone. |
| Breeze | Only take first contact with a trade path. Leer high/wide to break long angle crosshair placement. |
| Haven | Great for A Short/Garage fights. Do not hard lurk every round because Haven needs pressure across three lanes. |
| Lotus | Useful for A Main/C Main first fights. Dismiss back after pick; do not Dismiss through door into unknown stacks. |
| Split | Leer through Mid/A Main/B Main chokes. Do not be the only player taking Mid without support. |
| Sunset | Strong for B Main/Mid fights with Leer. Dismiss to safe angle; avoid overhealing in exposed lane. |
| Summit | Leer through new wall gaps to break angle holders. Do not Dismiss into unscouted wall-created pockets. |

## Review Rule

After every Reyna game, log one thing:

```txt
Was my agent pick valuable because of utility, space, picks, or tempo?
```
