---
type: map
map: Summit
status: current_pool
confidence:
agents: [Omen, Astra, Clove, Reyna, Chamber]
updated: 2026-07-04
---
# Summit

> Current focus: **Track wall states, punish teams that do not adapt to dropped-wall paths, and avoid autopilot executes based on old lane assumptions.**

## Map Identity

New three-lane, two-site map with droppable walls that can reshape lanes mid-round. Your first goal is building verified callouts and wall-state protocols.

## Main Win Condition

Track wall states, punish teams that do not adapt to dropped-wall paths, and avoid autopilot executes based on old lane assumptions.

## Important Areas

- Lane 1 / outer pressure
- Lane 2 / mid pressure
- Lane 3 / opposite outer pressure
- Droppable wall zones
- Site choke 1
- Site choke 2
- Retake corridors
- Spawn rotation path

## Attack Gameplan

Default across all three lanes, record which wall states are active, then hit the weakest rotation path. Do not assume a lane is safe after wall changes.

### First 20 Seconds

| Role | Job |
|---|---|
| Controller | Deny info or support first map-control fight. Do not smoke on autopilot. |
| Reyna | Fight first/second contact only with trade path and Leer timing. |
| Chamber | Protect flank or take safe pick angle with Rendezvous ready. |
| Spike carrier | Stay behind first contact and avoid isolation. |
| IGL/Caller | Identify whether enemy contests, stacks, or gives space. |

### Attack Protocols

- If first pick is gained: slow, group, and convert with trades.
- If first death is lost: avoid panic exec; find free map space or isolate a response kill.
- If defenders over-rotate: fake pressure and late-hit the opposite side.
- If defenders never rotate: punish anchor with full hit and post-plant spread.

## Defense Gameplan

Call wall state instantly, hold crossfires around changed geometry, and do not rotate until lane pressure + spike/utility confirms the hit.

### Rotation Rules

- Rotate on spike seen, 3+ players confirmed, or major execute utility.
- Do not leave your anchor alone without calling what space is open.
- If you give up a lane, say it clearly.
- If enemy defaults slowly, re-clear with two or hold discipline.

## Agent Plans

### Omen
Use smokes to isolate new wall gaps. Paranoia through compressed wall-created corridors. Verify one-ways before adding them to the live library.

### Astra
Global stars are ideal for wall-state chaos: place stars on common wall gaps, plant zones, and retake paths; recall to fake a wall-side hit.

### Clove
Great for early ranked adaptation: Ruse the most dangerous wall gap, Meddle close fights, and keep fighting with trade protocol.

### Reyna
Leer through new wall gaps to break angle holders. Do not Dismiss into unscouted wall-created pockets.

### Chamber
Trademark the most common wall-change flank. Rendezvous lets you test aggressive angles safely while learning the map.

## Pistol Plans

### Attack Pistol
- Play grouped, trade-heavy Valorant.
- Use one piece of utility to enter or deny info.
- Do not split too thin unless you have a very clear timing.

### Defense Pistol
- Fight with two or play retake. No solo hero wide swings.
- If contact appears, call count immediately and delay.

## Anti-Eco Protocol

- Clear close corners with numbers.
- Keep spike away from first contact.
- Do not give isolated rifles.
- After first pick, slow down and trade.

## Bonus Protocol

- Do not dry fight rifles across long sightlines.
- Use utility to isolate one defender.
- Plant is already huge value; post-plant discipline matters more than chasing kills.

## Retake Rules

- Group before touching site.
- Smoke the lane that creates the worst crossfire.
- Clear close first, then plant zone, then back-site/deep positions.
- Do not defuse tap without teammates ready to punish swings.

## Common Mistakes

| Mistake | Why It Loses | Correction |
|---|---|---|
| Autopilot default | Enemy reads timing and stacks correctly | Change first 20 seconds every 2-3 rounds |
| Dry first contact | Gives free opening death | Link contact to utility/trade |
| Panic rotate | Opens weak site/fake | Wait for real info |
| No post-plant spread | Retake clears one lane | Hold crossfire: main + site + late flank/lurk |
| Overheat after pick | Throws advantage | Convert numbers, do not chase |

## VOD Review Prompts

- Did I know the enemy pattern by round 5?
- Which lane did we control for free?
- Which utility created the winning timing?
- Was our first death useful, traded, or wasted?
- Did we lose because of map control, utility, mechanics, or mental?
