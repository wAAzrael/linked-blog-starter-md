---
type: map
map: Ascent
status: current_pool
confidence:
agents: [Omen, Astra, Clove, Reyna, Chamber]
updated: 2026-07-04
---
# Ascent

> Current focus: **Win Mid without bleeding first death; convert Mid pressure into A splits, B splits, or fake pressure.**

## Map Identity

Mid-control map where rotations and site hits are dictated by who owns Tiles, Catwalk, Market, and Tree.

## Main Win Condition

Win Mid without bleeding first death; convert Mid pressure into A splits, B splits, or fake pressure.

## Important Areas

- Top Mid
- Tiles
- Catwalk
- Tree
- A Main
- B Main
- Market
- Boat House

## Attack Gameplan

Default A Main + B Main pressure while two fight for Mid with utility. Do not exec a site until you know whether defenders are contesting Mid or stacking a main lane.

### First 20 Seconds

| Role | Job |
|---|---|
| Controller | Deny info or support first map-control fight. Do not smoke on autopilot. |
| Reyna | Fight first/second contact only with trade path and Leer timing. |
| Chamber | Protect flank or take safe pick angle with Rendezvous ready. |
| Spike carrier | Stay behind first contact and avoid isolation. |
| IGL/Caller | Identify whether enemy contests, stacks, or gives space. |

### Attack Protocols

- If first pick is gained: slow, group, and convert with trades.
- If first death is lost: avoid panic exec; find free map space or isolate a response kill.
- If defenders over-rotate: fake pressure and late-hit the opposite side.
- If defenders never rotate: punish anchor with full hit and post-plant spread.

## Defense Gameplan

Protect Tree/Market info, delay first smoke, rotate only on spike/multiple bodies/key utility.

### Rotation Rules

- Rotate on spike seen, 3+ players confirmed, or major execute utility.
- Do not leave your anchor alone without calling what space is open.
- If you give up a lane, say it clearly.
- If enemy defaults slowly, re-clear with two or hold discipline.

## Agent Plans

### Omen
Delay Top Mid smoke until Mid players are ready; Paranoia A Main/Tree or B Lane; save a smoke for post-plant or retake.

### Astra
Star Mid choke, Tree, Market/Lane. Use recalls to fake presence, pull default plant or defuse, stun Tree/Market swings.

### Clove
Ruse Heaven/Tree or Market/CT with tempo. Meddle close pockets before contact. Ult only when team can trade revive.

### Reyna
Leer for Mid/Cat or A Main entry; Dismiss back into traded space, not deeper into site alone.

### Chamber
Rendezvous for A Main/B Main early pick or Market OP timing; Trademark Cat/B Main flank depending on default.

## Pistol Plans

### Attack Pistol
- Play grouped, trade-heavy Valorant.
- Use one piece of utility to enter or deny info.
- Do not split too thin unless you have a very clear timing.

### Defense Pistol
- Fight with two or play retake. No solo hero wide swings.
- If contact appears, call count immediately and delay.

## Anti-Eco Protocol

- Clear close corners with numbers.
- Keep spike away from first contact.
- Do not give isolated rifles.
- After first pick, slow down and trade.

## Bonus Protocol

- Do not dry fight rifles across long sightlines.
- Use utility to isolate one defender.
- Plant is already huge value; post-plant discipline matters more than chasing kills.

## Retake Rules

- Group before touching site.
- Smoke the lane that creates the worst crossfire.
- Clear close first, then plant zone, then back-site/deep positions.
- Do not defuse tap without teammates ready to punish swings.

## Common Mistakes

| Mistake | Why It Loses | Correction |
|---|---|---|
| Autopilot default | Enemy reads timing and stacks correctly | Change first 20 seconds every 2-3 rounds |
| Dry first contact | Gives free opening death | Link contact to utility/trade |
| Panic rotate | Opens weak site/fake | Wait for real info |
| No post-plant spread | Retake clears one lane | Hold crossfire: main + site + late flank/lurk |
| Overheat after pick | Throws advantage | Convert numbers, do not chase |

## VOD Review Prompts

- Did I know the enemy pattern by round 5?
- Which lane did we control for free?
- Which utility created the winning timing?
- Was our first death useful, traded, or wasted?
- Did we lose because of map control, utility, mechanics, or mental?
