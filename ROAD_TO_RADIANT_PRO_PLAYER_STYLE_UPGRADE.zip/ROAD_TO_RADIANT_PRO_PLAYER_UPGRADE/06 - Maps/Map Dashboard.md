# Map Dashboard

## Current Competitive Pool

- [[06 - Maps/Map Pool/Ascent]]
- [[06 - Maps/Map Pool/Breeze]]
- [[06 - Maps/Map Pool/Haven]]
- [[06 - Maps/Map Pool/Lotus]]
- [[06 - Maps/Map Pool/Split]]
- [[06 - Maps/Map Pool/Sunset]]
- [[06 - Maps/Map Pool/Summit]]

## Archive / Team Prep

- [[06 - Maps/Archive Maps/Bind]]
- [[06 - Maps/Archive Maps/Fracture]]

## Map Review Process

For every map, keep three layers:

1. **Ranked plan** — simple repeatable rounds.
2. **Anti-pattern notes** — what enemies keep doing.
3. **Utility library** — verified smokes, flashes, traps, stars, retake utility.

## Current Weak Map Tracker

| Map | Confidence /10 | Main issue | Next custom/VOD task |
|---|---:|---|---|
| Ascent |  |  |  |
| Breeze |  |  |  |
| Haven |  |  |  |
| Lotus |  |  |  |
| Split |  |  |  |
| Sunset |  |  |  |
| Summit |  |  |  |
