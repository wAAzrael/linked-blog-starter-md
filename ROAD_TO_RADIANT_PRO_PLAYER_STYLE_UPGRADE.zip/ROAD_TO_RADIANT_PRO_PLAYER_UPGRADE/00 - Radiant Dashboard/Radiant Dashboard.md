---
type: dashboard
status: active
updated: 2026-07-04
---
# Radiant Dashboard

## Start Here

- [[PRO UPGRADE - START HERE]]
- [[00 - Radiant Dashboard/Top 1 Daily Operating System]]
- [[00 - Radiant Dashboard/Current Focus]]
- [[18 - Performance and Queue Control/Pre-Session Checklist]]
- [[19 - Round Protocols/Round Protocols Dashboard]]
- [[15 - Utility Library/Utility Dashboard]]
- [[16 - Matchup Library/Matchup Dashboard]]
- [[23 - Pro Player Style Lab/Pro Player Style Lab Dashboard]]

## Current Ranked Identity

**Pro-style study:** [[23 - Pro Player Style Lab/Players/Hybrid Style - My Version|Primmie calm aim + canezerra pressure + Solada tempo]]



**Primary identity:** controller brain with enough mechanics to punish mistakes.

**Agent pool:**
- Main controller core: [[05 - Roles and Agents/Omen/Omen Playbook|Omen]], [[05 - Roles and Agents/Astra/Astra Playbook|Astra]], [[05 - Roles and Agents/Clove/Clove Playbook|Clove]]
- Duelist comfort: [[05 - Roles and Agents/Reyna/Reyna Playbook|Reyna]]
- Flex/sentinel: [[05 - Roles and Agents/Chamber/Chamber Playbook|Chamber]]

## Current Map Pool

- [[06 - Maps/Map Pool/Ascent]]
- [[06 - Maps/Map Pool/Breeze]]
- [[06 - Maps/Map Pool/Haven]]
- [[06 - Maps/Map Pool/Lotus]]
- [[06 - Maps/Map Pool/Split]]
- [[06 - Maps/Map Pool/Sunset]]
- [[06 - Maps/Map Pool/Summit]]

## Daily Loop

1. Warm up hands.
2. Read current focus.
3. Pick agent/map rule.
4. Play 3-game block.
5. Log one repeated mistake.
6. Update weekly review.

## Active Focus Slots

| Slot | Focus | Evidence | Next Correction |
|---|---|---|---|
| Mechanics |  |  |  |
| Game sense |  |  |  |
| Utility |  |  |  |
| Mental |  |  |  |
| Map |  |  |  |

## RR Protection Rules

- Stop ranked after two games of obvious autopilot.
- Stop after three losses unless the losses are clean and reviewable.
- Never queue to “win it back.” Queue only when you have a correction.
- If you cannot name your last repeated mistake, you are not reviewing enough.
