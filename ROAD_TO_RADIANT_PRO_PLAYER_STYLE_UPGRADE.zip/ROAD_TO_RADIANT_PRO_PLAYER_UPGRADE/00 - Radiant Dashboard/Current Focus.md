---
type: focus
status: active
updated: 2026-07-04
---
# Current Focus

## Main 7-Day Focus

```txt
One thing I am fixing this week:
```

## Ranked Focus

### Before each game
- Map:
- Agent:
- First 20 seconds plan:
- Main risk:
- One correction from last game:

### During game
Repeat this between rounds:

> What is the enemy pattern? What is my job this round? How do we lose this round?

## Current Mechanical Focus

Pick one:
- First-bullet accuracy
- Mid-range burst discipline
- Long-range movement stop timing
- Crosshair height on off-angles
- Micro-adjustment calmness

## Current Game Sense Focus

Pick one:
- Rotating only on real information
- Playing man advantage correctly
- Slowing down after first pick
- Preserving utility for second contact
- Reading enemy default speed

## Do More / Do Less

| Do More | Do Less |
|---|---|
|  |  |
|  |  |
|  |  |


## Pro Style Focus

Pick one before queue:

| Style | Use When | Rule |
|---|---|---|
| [[23 - Pro Player Style Lab/Players/Primmie Style System|Primmie]] | aim feels rushed | calm crosshair, burst/reset |
| [[23 - Pro Player Style Lab/Players/Canezerra Style System|canezerra]] | you feel passive | committed first contact with purpose |
| [[23 - Pro Player Style Lab/Players/Solada Style System|Solada]] | lobby is chaotic | identify weak pattern and punish |
| [[23 - Pro Player Style Lab/Players/Hybrid Style - My Version|Hybrid]] | normal ranked block | confident fights only with reason |
