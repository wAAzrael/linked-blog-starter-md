---
type: dashboard
status: active
updated: 2026-07-04
---
# Top 1 Daily Operating System

## Daily Objective

A top player does not queue to “play better.” A top player queues with a measurable job.

```txt
Primary focus:
Agent focus:
Map focus:
Mechanic focus:
Decision focus:
Stop-loss rule:
```

## Pre-Queue Scan

| Check | Question | Pass? |
|---|---|---|
| Energy | Am I awake enough to track minimap + comms? |  |
| Hands | Are my first-bullet and micro-adjustments stable? |  |
| Mental | Am I chasing RR or playing correction-focused? |  |
| Agent | Do I know my first 20 seconds on my likely maps? |  |
| Stop-loss | Do I know when I stop? |  |

## The 3-Game Block

### Game 1
- Focus:
- Biggest lost round reason:
- Adjustment:

### Game 2
- Focus:
- Biggest lost round reason:
- Adjustment:

### Game 3
- Focus:
- Biggest lost round reason:
- Adjustment:

## After Block Decision

| Result | Action |
|---|---|
| Playing sharp + correcting mistakes | Continue one more block. |
| Aim good but decisions messy | VOD one round, then continue only if correction is clear. |
| Tilt / autopilot / ego peeking | Stop ranked. DM, VOD, or log off. |
| Two games same repeated mistake | Stop and review that mistake category. |

## Top 1 Rule

The player who improves fastest is not the player who plays the most. It is the player who loses the same round fewer times.
