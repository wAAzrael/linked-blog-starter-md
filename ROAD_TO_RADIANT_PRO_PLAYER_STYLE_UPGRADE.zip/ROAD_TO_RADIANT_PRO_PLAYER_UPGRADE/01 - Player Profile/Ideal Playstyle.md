# Ideal Playstyle

## Identity

A controller/flex player with sharp mechanics, fast pattern recognition, and calm mid-round decisions.

The goal is not to be passive. The goal is to be **useful before, during, and after contact**.

## Core Style

- Take space with a plan.
- Use utility to make fights unfair.
- Survive long enough to use second-cycle value.
- Call simple mid-round adjustments.
- Punish enemy patterns instead of reacting emotionally.

## Strength Formula

```txt
Clean mechanics + smoke discipline + pattern reading + tilt control = consistent climb
```

## My Best Round Type

1. Read enemy default speed.
2. Deny their first plan with smoke/utility/info.
3. Keep body alive for second contact.
4. Call the rotation/fake/re-hit.
5. Win post-plant or retake with numbers and utility.

## My Danger Round Type

- I get bored.
- I ego peek early.
- I die before using utility.
- I blame team pace instead of controlling the next decision.
- I queue again without reviewing why the round was lost.

## Top 1 Version Of Me

- Calm first 20 seconds.
- Precise mid-round language.
- No panic rotates.
- No dry solo fights after advantage.
- Reviews one repeated error every session.


## Pro Player Style Inspiration

My playstyle lab lives here: [[23 - Pro Player Style Lab/Pro Player Style Lab Dashboard]].

The ideal version is not pure controller/passive and not pure duelist/ego. It is:

```txt
Primmie calm aim + canezerra committed pressure + Solada tempo reading
```

For my pool:

- **Reyna:** punish isolated players, take clean first contact, Dismiss after value.
- **Chamber:** premium first bullet, TP after value, trap useful timing.
- **Omen:** create timing with smoke/paranoia/TP, then take calm fight.
- **Astra:** shape the round, activate utility for team/fight timing.
- **Clove:** use aggressive controller tempo without throwing first death.
