---
type: profile
status: active
updated: 2026-07-04
---
# Agent Pool

## Ranked Agent Pool

### Primary Core

| Agent | Role | Why I Pick It | Main Job |
|---|---|---|---|
| Omen | Controller | Flexible, ranked-proof, can support and make plays. | Smoke timing, Paranoia value, survive for second cycle. |
| Astra | Controller | Best when teamplay/exec structure exists. | Pre-plan stars, punish plants/defuses, fake pressure. |
| Clove | Controller | Good for tempo and chaotic ranked fights. | Smoke with team, trade, post-death smoke value. |

### Secondary / Flex

| Agent | Role | Why I Pick It | Main Job |
|---|---|---|---|
| Reyna | Duelist | Comfort pick when I want to take fights and snowball. | Create first contact with trade path, Dismiss safely, avoid selfish lurks. |
| Chamber | Sentinel/Flex | Pick-based defense, OP/rifle control, flank security. | Take safe opening duels, anchor with escape, protect flank. |

## Pick Rules

### Pick Omen when
- Team needs controller and nobody can call tempo.
- Map has strong Paranoia lanes.
- You need flexibility between support and playmaking.

### Pick Astra when
- Team will actually play off utility.
- Map rewards global pressure and post-plant/retake stars.
- You have clear plans before the round starts.

### Pick Clove when
- Ranked lobby is chaotic and needs tempo.
- You trust your fights but still need controller value.
- Team lacks trading and you can play closer to contact.

### Pick Reyna when
- Team already has smokes and sentinel basics.
- Enemy gives dry fights or weak trading.
- You are mechanically warm and mentally stable.

### Pick Chamber when
- Team lacks flank control or an anchor.
- You can punish predictable entry paths.
- Enemy is over-peeking early and not clearing traps.

## Do Not Pick Rules

- Do not pick Reyna because you are tilted and want to hard carry.
- Do not pick Astra if you are not ready to communicate stars and timings.
- Do not pick Chamber if you plan to lurk without creating defensive value.
- Do not pick Clove if you will die before using meaningful smokes.
- Do not pick Omen if you are going to smoke instantly every round with no pressure.
