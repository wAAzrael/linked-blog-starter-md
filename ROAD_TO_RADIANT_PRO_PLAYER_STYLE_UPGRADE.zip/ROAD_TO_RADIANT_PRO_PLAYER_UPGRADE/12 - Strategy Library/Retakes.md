# Retakes

## Principle

Retakes are won by grouping, isolating post-plant lanes, and clearing close before deep.

## Pro Checklist

- What is the trigger?
- Who is first contact?
- Who trades?
- What utility lands first?
- What space must be held after the hit?
- What is the fallback if first contact fails?

## Template

```txt
Round name:
Map:
Side:
Agent comp:
Trigger:
Utility order:
First contact:
Trade path:
Plant/retake plan:
Post-round review:
```

## Linked Protocols

- [[19 - Round Protocols/Round Protocols Dashboard]]
