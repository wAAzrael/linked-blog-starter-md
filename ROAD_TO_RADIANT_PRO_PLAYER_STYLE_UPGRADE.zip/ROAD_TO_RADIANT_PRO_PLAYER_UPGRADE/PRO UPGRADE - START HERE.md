---
type: pro_system
status: active
updated: 2026-07-04
tags: [valorant, radiant, pro-system]
---
# PRO UPGRADE - START HERE

This vault was upgraded into a **pro-style performance operating system**.

The goal is not to have more notes. The goal is to make every ranked session answer four questions:

1. **What is my win condition this map?**
2. **What is my agent job this round?**
3. **What mistake am I repeating?**
4. **What is the next correction that gains RR?**

## What changed

- Added full systems for utility, matchups, round protocols, anti-stratting, weekly review, queue control, and pro VOD review.
- Added deep folders for **Reyna** and **Chamber** in your actual agent pool.
- Expanded the controller core: **Omen / Astra / Clove**.
- Added current map pool workflow: **Ascent, Breeze, Haven, Lotus, Split, Sunset, Summit**.
- Preserved archive map prep for **Bind** and **Fracture**.
- Cleaned duplicate template structure: old duplicate templates moved to `99 - Archive/Old Duplicate Templates`.
- Removed the `.git` folder from this export so the shared vault is cleaner and safer to upload/import.

## How to use it like a top player

### Before queue
Open:
- [[00 - Radiant Dashboard/Top 1 Daily Operating System]]
- [[18 - Performance and Queue Control/Pre-Session Checklist]]
- [[00 - Radiant Dashboard/Current Focus]]

Pick **one** map/agent/mechanic focus. Not five.

### During queue
After every game, write only three things:

```txt
Map:
Agent:
Lost rounds because:
One correction next game:
```

### After queue
Open:
- [[07 - Match Journal/Session Summaries/Session Summary Template]]
- [[09 - Mistake Database/Mistake Dashboard]]
- [[17 - Weekly Reviews/Weekly Review Template]]

A Radiant vault is not a library. It is a feedback loop.
