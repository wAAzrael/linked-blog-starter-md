---
type: start
status: active
updated: 2026-07-04
---
# PRO STYLE UPGRADE - START HERE

This upgrade adds a **Pro Player Style Lab** built around the playstyle ideas you asked for:

- [[23 - Pro Player Style Lab/Players/Canezerra Style System|canezerra]] — committed confidence, explosive fight intent, pressure creation.
- [[23 - Pro Player Style Lab/Players/Primmie Style System|Primmie]] — calm aim, clean movement, crosshair discipline, fight patience.
- [[23 - Pro Player Style Lab/Players/Solada Style System|Solada]] — high-tempo duelist impact, fast punish timing, ranked chaos control.

The goal is not to copy their sens, crosshair, or clips blindly. The goal is to turn their best principles into your own ranked system for **Reyna, Chamber, Omen, Astra, and Clove**.

## Use It Like This

1. Open [[23 - Pro Player Style Lab/Pro Player Style Lab Dashboard]].
2. Pick one style focus for the day.
3. Run the matching DM mode from [[23 - Pro Player Style Lab/Training/Deathmatch Modes - Canezerra Primmie Solada]].
4. Queue with one ranked rule from [[23 - Pro Player Style Lab/Training/Ranked Transfer Protocol]].
5. After the session, fill [[23 - Pro Player Style Lab/Templates/Pro Style Session Review Template]].

## Best Starting Path

If your aim feels shaky:
- [[23 - Pro Player Style Lab/Players/Primmie Style System]]
- [[23 - Pro Player Style Lab/Mechanics/Primmie Calm Aim Protocol]]

If you feel too passive:
- [[23 - Pro Player Style Lab/Players/Canezerra Style System]]
- [[23 - Pro Player Style Lab/Mechanics/Commitment and First Contact Protocol]]

If ranked feels chaotic and you need to carry more:
- [[23 - Pro Player Style Lab/Players/Solada Style System]]
- [[23 - Pro Player Style Lab/Agent Translation/Reyna - Pro Style Translation]]

## Main Rule

> Copy principles. Do not copy ego.

A top player fight is not random confidence. It is a prepared fight with timing, angle discipline, and a way out or a trade plan.
