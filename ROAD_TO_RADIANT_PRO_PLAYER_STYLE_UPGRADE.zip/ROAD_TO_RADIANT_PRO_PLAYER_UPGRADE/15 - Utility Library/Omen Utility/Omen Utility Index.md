# Omen Utility Index

Main playbook: [[05 - Roles and Agents/Omen/Omen Playbook]]

## Current Map Pool

- [[15 - Utility Library/Omen Utility/Ascent - Omen Utility]]
- [[15 - Utility Library/Omen Utility/Breeze - Omen Utility]]
- [[15 - Utility Library/Omen Utility/Haven - Omen Utility]]
- [[15 - Utility Library/Omen Utility/Lotus - Omen Utility]]
- [[15 - Utility Library/Omen Utility/Split - Omen Utility]]
- [[15 - Utility Library/Omen Utility/Sunset - Omen Utility]]
- [[15 - Utility Library/Omen Utility/Summit - Omen Utility]]

## Utility Review Rule

After each game, add one utility note:

```txt
What utility gave value?
What utility was wasted?
What timing should I change?
```
