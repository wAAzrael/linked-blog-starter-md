# Chamber Utility Index

Main playbook: [[05 - Roles and Agents/Chamber/Chamber Playbook]]

## Current Map Pool

- [[15 - Utility Library/Chamber Utility/Ascent - Chamber Utility]]
- [[15 - Utility Library/Chamber Utility/Breeze - Chamber Utility]]
- [[15 - Utility Library/Chamber Utility/Haven - Chamber Utility]]
- [[15 - Utility Library/Chamber Utility/Lotus - Chamber Utility]]
- [[15 - Utility Library/Chamber Utility/Split - Chamber Utility]]
- [[15 - Utility Library/Chamber Utility/Sunset - Chamber Utility]]
- [[15 - Utility Library/Chamber Utility/Summit - Chamber Utility]]

## Utility Review Rule

After each game, add one utility note:

```txt
What utility gave value?
What utility was wasted?
What timing should I change?
```
