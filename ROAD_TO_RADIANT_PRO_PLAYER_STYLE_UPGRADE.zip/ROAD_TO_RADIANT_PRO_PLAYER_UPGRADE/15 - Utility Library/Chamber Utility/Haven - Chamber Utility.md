# Haven - Chamber Utility

Linked map: [[06 - Maps/Map Pool/Haven]]
Linked agent: [[05 - Roles and Agents/Chamber/Chamber Playbook]]

## Main Job

Trademark Garage/flank. Rendezvous for C Long/A Long opening pick and safe anchor escape.

## Attack Utility

| Situation | Utility | Timing | Purpose | Screenshot/Clip |
|---|---|---|---|---|
| Default |  |  | Deny info / take space |  |
| Execute |  |  | Isolate site fight |  |
| Mid-round |  |  | Fake / regroup / re-hit |  |
| Post-plant |  |  | Delay retake / protect spike |  |

## Defense Utility

| Situation | Utility | Timing | Purpose | Screenshot/Clip |
|---|---|---|---|---|
| Early info deny |  |  | Stop free lane info |  |
| Delay |  |  | Split execute wave |  |
| Retake |  |  | Clear/isolate post-plant |  |
| Save/exit |  |  | Survive or punish exits |  |

## Notes

- Add only verified utility here.
- If a smoke/flash/trap/star fails twice, move it to mistakes until corrected.
