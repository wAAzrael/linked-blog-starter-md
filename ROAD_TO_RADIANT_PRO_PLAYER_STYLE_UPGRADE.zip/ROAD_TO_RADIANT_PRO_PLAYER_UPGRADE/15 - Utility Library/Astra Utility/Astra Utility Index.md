# Astra Utility Index

Main playbook: [[05 - Roles and Agents/Astra/Astra Playbook]]

## Current Map Pool

- [[15 - Utility Library/Astra Utility/Ascent - Astra Utility]]
- [[15 - Utility Library/Astra Utility/Breeze - Astra Utility]]
- [[15 - Utility Library/Astra Utility/Haven - Astra Utility]]
- [[15 - Utility Library/Astra Utility/Lotus - Astra Utility]]
- [[15 - Utility Library/Astra Utility/Split - Astra Utility]]
- [[15 - Utility Library/Astra Utility/Sunset - Astra Utility]]
- [[15 - Utility Library/Astra Utility/Summit - Astra Utility]]

## Utility Review Rule

After each game, add one utility note:

```txt
What utility gave value?
What utility was wasted?
What timing should I change?
```
