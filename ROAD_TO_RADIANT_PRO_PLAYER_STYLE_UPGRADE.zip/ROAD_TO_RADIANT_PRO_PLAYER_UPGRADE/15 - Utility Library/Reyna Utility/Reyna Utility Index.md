# Reyna Utility Index

Main playbook: [[05 - Roles and Agents/Reyna/Reyna Playbook]]

## Current Map Pool

- [[15 - Utility Library/Reyna Utility/Ascent - Reyna Utility]]
- [[15 - Utility Library/Reyna Utility/Breeze - Reyna Utility]]
- [[15 - Utility Library/Reyna Utility/Haven - Reyna Utility]]
- [[15 - Utility Library/Reyna Utility/Lotus - Reyna Utility]]
- [[15 - Utility Library/Reyna Utility/Split - Reyna Utility]]
- [[15 - Utility Library/Reyna Utility/Sunset - Reyna Utility]]
- [[15 - Utility Library/Reyna Utility/Summit - Reyna Utility]]

## Utility Review Rule

After each game, add one utility note:

```txt
What utility gave value?
What utility was wasted?
What timing should I change?
```
