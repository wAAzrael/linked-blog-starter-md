# Smoke Discipline

## Good Smoke Checklist

- It blocks the angle that matters now.
- It lands before the teammate crossing/fighting needs it.
- It does not create a one-way for the enemy.
- It does not hide enemies in site pockets you still need to clear.
- It leaves at least one late-round option when possible.

## Smoke Timings

| Timing | Use |
|---|---|
| Instant | Stop dangerous info/OP line or deny rush. |
| Delayed | Hit after enemy utility fades or rotations commit. |
| Contact | Smoke when teammate is ready to cross/fight. |
| Retake | Isolate post-plant angle or deny main lane. |
| Fake | Force enemy rotate without committing bodies. |

## Common Bad Smokes

| Bad Smoke | Problem | Fix |
|---|---|---|
| Autopilot choke smoke | Enemy waits it out | Smoke with pressure/timing |
| Deep smoke with uncleared pockets | Enemy hides on site | Smoke angle, not your own clear path |
| Late smoke | Teammate dies before value | Communicate timing earlier |
| Both smokes early | No late round | Preserve second-cycle value |
