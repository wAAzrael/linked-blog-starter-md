# Utility Dashboard

## Agent Utility Libraries

- [[15 - Utility Library/Omen Utility/Omen Utility Index]]
- [[15 - Utility Library/Astra Utility/Astra Utility Index]]
- [[15 - Utility Library/Clove Utility/Clove Utility Index]]
- [[15 - Utility Library/Reyna Utility/Reyna Utility Index]]
- [[15 - Utility Library/Chamber Utility/Chamber Utility Index]]

## Utility Principles

- Utility must be tied to timing.
- Utility must be communicated.
- Utility must either take space, deny info, isolate fight, delay, or convert objective.
- Utility that looks good but creates no action is low value.

## Screenshot Standard

For each lineup/smoke/setup, add:

```txt
Map:
Agent:
Side:
Round type:
Purpose:
Timing:
How to reproduce:
Failure condition:
Screenshot/video:
```
