# Clove Utility Index

Main playbook: [[05 - Roles and Agents/Clove/Clove Playbook]]

## Current Map Pool

- [[15 - Utility Library/Clove Utility/Ascent - Clove Utility]]
- [[15 - Utility Library/Clove Utility/Breeze - Clove Utility]]
- [[15 - Utility Library/Clove Utility/Haven - Clove Utility]]
- [[15 - Utility Library/Clove Utility/Lotus - Clove Utility]]
- [[15 - Utility Library/Clove Utility/Split - Clove Utility]]
- [[15 - Utility Library/Clove Utility/Sunset - Clove Utility]]
- [[15 - Utility Library/Clove Utility/Summit - Clove Utility]]

## Utility Review Rule

After each game, add one utility note:

```txt
What utility gave value?
What utility was wasted?
What timing should I change?
```
