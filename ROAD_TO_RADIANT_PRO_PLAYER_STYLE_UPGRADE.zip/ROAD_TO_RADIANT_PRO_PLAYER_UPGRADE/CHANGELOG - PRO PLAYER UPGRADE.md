# Changelog - Pro Player Upgrade

## 2026-07-04

### Added
- `15 - Utility Library`
- `16 - Matchup Library`
- `17 - Weekly Reviews`
- `18 - Performance and Queue Control`
- `19 - Round Protocols`
- `20 - Anti-Strat Enemy Patterns`
- `21 - Pro Review System`
- `22 - Patch Notes and Meta`
- Full Reyna folder
- Full Chamber folder
- Agent x map utility checklists for Omen, Astra, Clove, Reyna, Chamber
- Pro-level decision protocols for man advantage, disadvantage, anti-eco, eco, bonus, post-plant, retake, clutch, save, contact explode, fake, lurk punish
- Queue control system to avoid RR bleed
- Matchup files versus common ranked/team styles

### Reworked
- Dashboard system
- Agent pool
- Controller fundamentals
- Strategy library
- Templates
- Current map pool notes

### Cleaned
- Duplicate `99 - Templates` moved into archive.
- `.git` folder excluded from export.
