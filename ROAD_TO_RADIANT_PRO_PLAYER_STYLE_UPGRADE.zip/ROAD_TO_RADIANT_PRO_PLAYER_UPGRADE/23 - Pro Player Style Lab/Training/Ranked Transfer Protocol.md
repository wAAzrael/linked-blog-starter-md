# Ranked Transfer Protocol

## Why This Exists

A lot of players watch pros, get inspired, then throw ranked because they copy the clip instead of the condition behind the clip.

This file turns pro-style ideas into ranked rules.

## Before Queue

Choose one style:

```txt
Today I am training: Primmie / canezerra / Solada / Hybrid
Agent:
Rule:
Map pool risk:
Stop-loss:
```

## Style Rules

### Primmie Ranked Rule

Use when aim feels rushed.

- no panic sprays at mid/long range
- hold more, overpeek less
- clear one angle at a time
- reset after whiff
- take high-quality fights only

### canezerra Ranked Rule

Use when you feel passive.

- take planned first contact
- commit with utility/trade/escape
- pressure enemy repeated timings
- after value, leave
- do not half-swing

### Solada Ranked Rule

Use when lobby is chaotic.

- identify enemy weak pattern by round 4
- change tempo when enemy adapts
- punish isolated players
- simplify calls
- do not let chaos break crosshair discipline

## Round Conversion Examples

### Reyna Attack

```txt
Enemy anchor plays alone → call contact → Leer → swing → kill → Dismiss → regroup/hit
```

### Chamber Defense

```txt
Enemy always takes main early → TP setup → hold premium angle → one shot → TP → play retake/info
```

### Omen Mid-Round

```txt
Enemy over-rotates to first noise → fake smoke → wait rotate → hit opposite or lurk timing
```

### Clove Fast Ranked Round

```txt
Team wants to rush → smoke before contact → fight isolated angle → trade/decay → post-death smoke if needed
```

### Astra Team Round

```txt
Enemy fast pushes → pre-star choke → delay → call stack/rotate → use suck/stun for retake
```

## After Game Review

Only answer three questions:

1. Did I apply today's rule?
2. Which death broke the rule?
3. What is the one correction next game?

If you cannot answer, do not queue another game yet.
