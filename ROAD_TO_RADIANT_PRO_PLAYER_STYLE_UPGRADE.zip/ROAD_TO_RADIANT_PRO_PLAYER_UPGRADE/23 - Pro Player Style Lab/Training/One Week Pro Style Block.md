# One Week Pro Style Block

## Goal

Train one style per day without changing your entire identity.

## Weekly Plan

| Day | Focus | Ranked Rule |
|---|---|---|
| Day 1 | Primmie calm aim | No panic spray, reset after whiff. |
| Day 2 | canezerra commit | Planned first contact only. |
| Day 3 | Solada tempo | Identify enemy weak pattern by round 4. |
| Day 4 | Hybrid | Confident fights only with reason. |
| Day 5 | Reyna translation | Leer + Dismiss discipline. |
| Day 6 | Controller translation | Utility creates fight, aim finishes it. |
| Day 7 | Review | VOD 3 rounds, update mistakes. |

## Daily Log

```txt
Date:
Focus style:
Agent:
Games:
Best round:
Worst repeated mistake:
One clip to review:
Next correction:
```

## Success Criteria

You succeeded if:
- you played with one clear rule
- you reviewed one repeated mistake
- your deaths became more explainable
- you stopped copying ego and copied principles

You failed if:
- you changed crosshair/sens randomly
- you watched highlights instead of rounds
- you played more but reviewed less
- you blamed teammates without finding your own correction
