# Deathmatch Modes - Canezerra Primmie Solada

## Primmie DM - Calm Aim

Goal: make kills look easy.

Rules:
- Vandal/Guardian only.
- No crouch.
- No spray longer than 4 bullets.
- Hold angles sometimes instead of constantly running.
- Focus on crosshair being ready before enemy appears.

Scoring:

| Metric | Target |
|---|---|
| Panic sprays | 0-3 max |
| Clean burst kills | 20+ |
| Deaths from bad crosshair | log only |

Mental cue:

> Place first, shoot second.

## canezerra DM - Commit And Reset

Goal: remove hesitation.

Rules:
- choose fights deliberately
- once you swing, commit cleanly
- after kill, reposition instantly
- no standing still after value
- no half-peeks where you are not ready to shoot

Scoring:

| Metric | Target |
|---|---|
| Hesitation deaths | under 5 |
| Reposition after kill | every time |
| Clean first bullet attempts | high priority |

Mental cue:

> If I go, I go clean. If I leave, I leave fully.

## Solada DM - Chaos Control

Goal: stay clean inside messy fights.

Rules:
- clear one angle even in chaos
- do not chase spawns blindly
- if shot from side, move to cover before ego fighting
- after every kill, reset crosshair and body position
- train calm target switching

Scoring:

| Metric | Target |
|---|---|
| Deaths while exposed to 2+ angles | reduce |
| Reposition after kill | high |
| Calm second duel wins | track |

Mental cue:

> Chaos is readable if I slow my decision down.

## Hybrid DM

Play one DM with 3 phases:

```txt
0-3 min: Primmie calm aim
3-6 min: canezerra commit/reset
6-end: Solada chaos control
```

Review after:

- Which style felt weakest today?
- Did I rush shots?
- Did I hesitate?
- Did I lose control in chaos?
