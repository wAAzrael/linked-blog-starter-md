# Daily Routine - Pro Style Hybrid

## Full Routine: 60-75 Minutes Before Ranked

### 1. Hand Wake-Up - 5 min

- wrist/forearm loose
- no deathgrip
- smooth mouse movement
- relaxed shoulders

### 2. Calm Aim Block - 15 min

Inspired by Primmie-style discipline.

```txt
5 min one-taps
5 min burst reset
5 min strafe-stop shots
```

Rules:
- no crouch
- no panic spray
- reset after whiff

### 3. Commit Block - 10 min

Inspired by canezerra-style pressure.

In DM or range:
- choose a target
- commit fully to the angle
- burst/reset
- leave/reposition after kill

Do not half-swing.

### 4. Chaos Control DM - 1 Game

Inspired by Solada-style ranked impact.

Rules:
- fight only one angle at a time
- if spawned in chaos, move to cover first
- every kill must be followed by reposition
- no scoreboard focus

### 5. Agent-Specific Micro - 10 min

Pick your queue agent.

| Agent | Micro |
|---|---|
| Reyna | Leer swing timing + Dismiss decision. |
| Chamber | First bullet + TP discipline. |
| Omen | Smoke/paranoia fight timing. |
| Astra | Star activation into teammate/fight. |
| Clove | Smoke isolate + decay/fight timing. |

### 6. Ranked Focus - 2 min

Fill:

```txt
Today I copy: Primmie / canezerra / Solada / Hybrid
Main rule:
Agent:
Map weakness:
Stop-loss:
```

## Short Routine: 20 Minutes

```txt
5 min calm one-taps
5 min burst/reset
1 DM with one rule
2 min focus note
```

## Emergency Routine: Bad Aim Day

Do not force high-tempo Reyna if aim is shaky.

- 1 calm aim DM
- queue Omen/Clove if you can still make good decisions
- avoid ego peeking for first 5 rounds
- play utility/value until mechanics stabilize
