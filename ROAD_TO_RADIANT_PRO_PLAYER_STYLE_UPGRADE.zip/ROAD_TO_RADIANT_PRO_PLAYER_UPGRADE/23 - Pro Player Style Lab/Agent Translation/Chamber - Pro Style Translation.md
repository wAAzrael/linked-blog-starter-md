# Chamber - Pro Style Translation

## Your Chamber Identity

Chamber is not “Reyna with a trap.” Chamber is **controlled first contact**.

```txt
Primmie first bullet + canezerra confidence + Chamber escape = clean value
```

## Core Rules

### Rendezvous Discipline

Your TP must answer:

- where do I escape?
- can enemy chase me?
- do I give up site for free?
- can teammate use my contact?
- what angle do I hold after TP?

Bad Chamber players place TP for comfort. Good Chamber players place TP for the round plan.

### Trademark Rules

Use trap to cover:
- flank timing
- late lurk
- extremity pressure
- retake space
- your own aggressive setup escape

Do not place trap randomly where it gives no useful timing info.

## First Contact Types

| Type | Use When | Rule |
|---|---|---|
| OP hold | Enemy must cross long angle | Shoot once, TP/reset. |
| Rifle off-angle | Enemy clears common angle first | One kill then reposition. |
| Contact bait | Teammate plays off your shot | Call before contact. |
| Trap punish | Trap detects push/lurk | Fight only with angle advantage. |

## Attack Chamber

- Lurk only when it creates timing or holds flank.
- Do not bait team from spawn while spike needs help.
- Hold post-plant long lines if spike is planted for you.
- Use Headhunter for clean eco/bonus value.

## Defense Chamber

- Take early angle with TP exit.
- If no contact, do not stay useless forever.
- Rotate after trap/contact info.
- Save OP only when round is truly unrecoverable.

## Pro Style Translation

### Primmie
- Premium first bullet.
- Hold calm angle, let enemy walk into crosshair.

### canezerra
- Commit to first contact when TP makes it high value.
- Pressure enemy default by making one lane dangerous.

### Solada
- Punish repeated push/lurk timings.
- Change angle after every kill so ranked players cannot prefire you twice.

## Mistakes To Track

| Mistake | Correction |
|---|---|
| TP placed too far from useful fight | Build setup around fight first. |
| Greed after first kill | TP or reposition. |
| Trap gives useless info | Place for timing that changes decision. |
| Lurk too slow | Sync with team hit. |
| OP save too early | Try retake if numbers/time allow. |
