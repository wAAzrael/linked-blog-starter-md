# Omen Astra Clove - Pro Style Translation

## Controller Problem

Mechanical players often forget that controllers win by being valuable before the duel even happens.

Your goal:

```txt
Use controller utility to create pro-style fights instead of taking dry ranked fights.
```

## Omen

### Primmie Translation
- Smoke to reduce angle count.
- Hold calm off-angle after smoke.
- Paranoia then burst, do not panic swing.

### canezerra Translation
- Use paranoia/TP to create pressure with purpose.
- Take aggressive timing only after smoke denies trade angles.
- TP is a timing tool, not a random highlight button.

### Solada Translation
- Punish predictable anchors with paranoia pressure.
- Change tempo with late lurk/fake smokes.
- If enemy over-rotates, call re-hit.

## Astra

### Primmie Translation
- Calm aim after utility activation.
- Do not rush your shot while managing stars.
- Fight after suck/stun only when crosshair is already ready.

### canezerra Translation
- Create committed team pressure with pull/stun timing.
- Force enemy out of comfort positions.
- Call the exact swing timing.

### Solada Translation
- Read enemy tempo and pre-place stars to punish habits.
- If they rush, delay. If they default, fake pressure and rotate.

## Clove

### Primmie Translation
- Do not let aggressive kit make your mechanics sloppy.
- Smoke, isolate, burst/reset.

### canezerra Translation
- Clove can take more pressure fights, but only with value.
- Post-death smoke is insurance, not permission to int.

### Solada Translation
- Great for ranked tempo.
- Fight, trade, decay, smoke after death, keep team moving.

## Controller Fight Rules

Good controller fight:
- after smoke reduces angles
- after enemy utility is baited
- with teammate timing
- with escape/cover
- after you already placed key utility

Bad controller fight:
- before smokes go down
- while holding utility in hand
- isolated dry fight on defense
- first death with all utility unused
- post-plant chase after spike is planted well

## Ranked Rule

> My utility creates the fight. My aim finishes it.
