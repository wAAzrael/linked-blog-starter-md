# Reyna - Pro Style Translation

## Your Reyna Identity

Reyna is your main “mechanical carry” translation for canezerra/Primmie/Solada ideas.

```txt
Primmie aim discipline + canezerra commit + Solada tempo punish = Reyna carry without throwing
```

## First Contact Rules

### Good First Contact

- Leer forces enemy crosshair/vision reaction.
- Teammate can trade.
- Angle count is controlled.
- You can Dismiss after kill.
- The fight creates space or punishes a pattern.

### Bad First Contact

- Dry swing into unknown stack.
- Fight with no trade and no Dismiss route.
- Repeek same angle after being tagged.
- Swing because team is slow and you are bored.
- Empress ego mode with no plan.

## Leer Rules

| Situation | Leer Usage |
|---|---|
| Entry | Throw high/deep enough to pull crosshair away. |
| Contact punish | Leer as you swing known enemy. |
| Retake | Leer for teammate contact, not just your kill. |
| Clutch | Use Leer to isolate one duel or fake pressure. |
| Anti-OP | Leer only with swing timing, not too early. |

## Dismiss Rules

Dismiss if:
- second enemy can trade
- you are exposed to multiple angles
- you already got entry value
- spike is down and reposition wins round

Do not Dismiss if:
- you need to hold the angle for teammate
- second enemy is already one bullet and isolated
- you are safe behind cover
- Dismiss would give up post-plant control

## Round Protocols

### Attack Default

1. Take space with team or lurk with purpose.
2. Use Leer to force favorable first contact.
3. After kill, Dismiss to reset unless the second fight is guaranteed.
4. Do not over-lurk when spike needs entry pressure.

### Defense

1. Hold punish angle early.
2. If enemy defaults slowly, take controlled re-clear with teammate.
3. If enemy rushes, Leer delay + fight one isolated target.
4. After first kill, fall or reposition.

### Post-Plant

- Play off spike, not ego.
- Use Leer late to force tap panic.
- Hide after kill if time is low.
- Do not Dismiss away from winning position without reason.

## DM Transfer

Best modes:
- Primmie calm aim DM
- canezerra commit/reset DM
- Solada chaos control DM

## Reyna Mistakes To Track

| Mistake | Correction |
|---|---|
| Dry first death | Need Leer, trade, or timing. |
| Dismiss greed | Leave after value. |
| Empress overheat | Keep fight selection rules. |
| Lurking too long | Rejoin on team timing. |
| Leer too shallow | Make enemy actually react. |
