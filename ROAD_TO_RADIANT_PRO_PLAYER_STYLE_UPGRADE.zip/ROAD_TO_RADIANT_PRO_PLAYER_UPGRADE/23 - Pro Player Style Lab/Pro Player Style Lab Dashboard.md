---
type: dashboard
status: active
updated: 2026-07-04
---
# Pro Player Style Lab Dashboard

## Core Idea

You are building a hybrid style:

```txt
Primmie calm aim + canezerra committed confidence + Solada ranked tempo
= mechanical pressure without throwing rounds
```

## Player Systems

- [[23 - Pro Player Style Lab/Players/Canezerra Style System]]
- [[23 - Pro Player Style Lab/Players/Primmie Style System]]
- [[23 - Pro Player Style Lab/Players/Solada Style System]]
- [[23 - Pro Player Style Lab/Players/Hybrid Style - My Version]]

## Mechanical Protocols

- [[23 - Pro Player Style Lab/Mechanics/Shared Mechanical DNA]]
- [[23 - Pro Player Style Lab/Mechanics/Primmie Calm Aim Protocol]]
- [[23 - Pro Player Style Lab/Mechanics/Commitment and First Contact Protocol]]
- [[23 - Pro Player Style Lab/Mechanics/Fight Selection Matrix]]
- [[23 - Pro Player Style Lab/Mechanics/Movement and Aim Workbook]]
- [[23 - Pro Player Style Lab/Mechanics/Confidence Without Ego Protocol]]

## Agent Translation

- [[23 - Pro Player Style Lab/Agent Translation/Reyna - Pro Style Translation]]
- [[23 - Pro Player Style Lab/Agent Translation/Chamber - Pro Style Translation]]
- [[23 - Pro Player Style Lab/Agent Translation/Omen Astra Clove - Pro Style Translation]]

## Training

- [[23 - Pro Player Style Lab/Training/Daily Routine - Pro Style Hybrid]]
- [[23 - Pro Player Style Lab/Training/Deathmatch Modes - Canezerra Primmie Solada]]
- [[23 - Pro Player Style Lab/Training/Ranked Transfer Protocol]]
- [[23 - Pro Player Style Lab/Training/One Week Pro Style Block]]

## VOD Study

- [[23 - Pro Player Style Lab/VOD Study/Canezerra VOD Study Template]]
- [[23 - Pro Player Style Lab/VOD Study/Primmie VOD Study Template]]
- [[23 - Pro Player Style Lab/VOD Study/Solada VOD Study Template]]
- [[23 - Pro Player Style Lab/VOD Study/Clip Stealing Checklist]]

## Templates

- [[23 - Pro Player Style Lab/Templates/Pro Style Session Review Template]]
- [[23 - Pro Player Style Lab/Templates/Pro Style Clip Note Template]]

## Warning

The point is **not** to become a montage player. The point is to become a player who takes high-quality fights with calm mechanics and repeatable decisions.
