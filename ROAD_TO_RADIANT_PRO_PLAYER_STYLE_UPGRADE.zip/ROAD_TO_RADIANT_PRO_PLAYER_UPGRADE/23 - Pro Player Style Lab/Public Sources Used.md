# Public Sources Used

These notes are a **playstyle study framework**, not a claim that the players personally train exactly this way.

## Public Reference Points

- Primmie profile/settings page: ProSettings.net, `https://prosettings.net/players/primmie/`
- canezerra profile/stat page: THESPIKE.GG, `https://www.thespike.gg/player/canezerra/67279`
- Solada profile/stat page: THESPIKE.GG, `https://www.thespike.gg/player/solada/62421`
- Community VOD discussion can be useful for ideas, but treat it as lower-confidence than full VOD review.

## How To Use Sources

1. Watch full rounds, not only highlights.
2. Track first 20 seconds, not only kills.
3. Ask what made the fight favorable.
4. Convert one idea into a ranked rule.
5. Test it for one week before judging.

## What Not To Do

- Do not copy a sensitivity just because a player is good.
- Do not copy reckless peeks without copying the setup behind them.
- Do not assume a highlight is a correct repeatable habit.
- Do not change your whole playstyle every day.
