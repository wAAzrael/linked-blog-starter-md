# Shared Mechanical DNA

The three styles are different, but the shared mechanics are the same.

## 1. Crosshair Is Already Close

A top aimer is not constantly doing huge flicks. Most kills come from:

- correct head height
- pre-aiming common paths
- clearing angle slices
- holding where the enemy must appear
- correcting only a small amount

## 2. First Bullet Is Prepared

Before shooting:

```txt
feet stable + crosshair close + target confirmed = fire
```

If any part is missing, the fight becomes messy.

## 3. Movement Is A Weapon, Not A Habit

Movement should answer a question:

- Am I dodging a pre-aim?
- Am I isolating one angle?
- Am I baiting a shot?
- Am I resetting after a missed burst?
- Am I moving to cover after value?

If not, you are just moving because you are nervous.

## 4. Fight Selection Beats Raw Aim

A worse aimer wins good fights against a better aimer who takes bad fights.

Good fights:
- enemy is isolated
- enemy is utility-blinded/smoked/displaced
- enemy is clearing another angle
- enemy is mid-rotation
- teammate can trade
- you have escape

Bad fights:
- two enemies can see you
- no trade and no escape
- you are fighting after advantage with no need
- you repeek the same angle while tagged
- you swing because you are tilted

## 5. Reset Speed

The difference between good and elite mechanics is reset speed.

```txt
Whiff → stop ego → move → re-place → shoot again
```

Most players lose because they whiff once and then emotionally commit to a bad spray.
