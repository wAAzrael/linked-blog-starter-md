# Fight Selection Matrix

Use this before peeking. It should become automatic.

## Fight Quality Score

Give each fight 1 point per positive:

| Factor | Yes? |
|---|---|
| I know where enemy can be. |  |
| Crosshair is pre-aimed. |  |
| I am exposed to one main angle. |  |
| Teammate can trade. |  |
| I have utility or escape. |  |
| Enemy is pressured by timing/utility. |  |
| Round state allows risk. |  |

## Score Meaning

| Score | Action |
|---:|---|
| 0-2 | Do not take it unless desperate. |
| 3-4 | Take only if the reward is high. |
| 5-6 | Good fight. Commit cleanly. |
| 7 | Premium fight. Take space/value. |

## Round State Adjustment

### When Ahead

You need a higher score to fight.

```txt
5v4 / 4v3 = only premium fights or trade fights
```

### When Behind

You can take lower-score fights if they create equalizer value.

```txt
4v5 / 3v4 = create timing, isolate, or stack with teammate
```

### Post-Plant

Do not take ego fights unless:

- spike is planted badly
- enemy has no time
- teammate can trade
- utility forces them into you

## Agent Adjustments

| Agent | What changes |
|---|---|
| Reyna | Dismiss raises fight score only if kill is realistic. |
| Chamber | TP raises score only if placed safely. |
| Omen | Paranoia/smoke raises score if timing is synced. |
| Astra | Suck/stun raises score if teammate can play off it. |
| Clove | Post-death smoke does not make bad fights good. |
