# Confidence Without Ego Protocol

## Difference

| Confidence | Ego |
|---|---|
| I know why this fight is good. | I want to prove I am better. |
| I can leave after value. | I chase one more. |
| I use utility/trade/timing. | I dry swing boredom fights. |
| I accept reset after whiff. | I panic spray. |
| I play round win condition. | I play clip win condition. |

## The Confidence Sentence

Before a fight:

```txt
I am taking this because ______.
```

Valid answers:
- teammate can trade me
- my utility gives timing
- enemy repeats this push
- I have escape
- we need space now
- they are rotating and exposed

Invalid answers:
- I feel like I should kill him
- I am annoyed
- I want clip
- I have not fought in a while
- I need to carry

## Stop-Greed Rule

After getting a kill:

```txt
escape > reposition > isolate > only then re-fight
```

## Ranked Mantra

> I can be the best aimer in the server and still not owe the enemy a 50/50.

## Review

After every loss, mark deaths:

| Death | Confidence or ego? | Correction |
|---|---|---|
|  |  |  |
