# Movement and Aim Workbook

## Daily Micro-Skills

### 1. Stop Timing

Goal: shoot only when accurate.

Drill:

```txt
Strafe left → stop → one bullet
Strafe right → stop → one bullet
Repeat for 5 minutes
```

Check:
- bullet lands center/head
- no moving shots
- no panic second bullet

### 2. Angle Slicing

Goal: clear one angle at a time.

In custom or DM:
- imagine every corner has an enemy
- expose only the smallest slice
- crosshair leads the body
- stop before shooting

### 3. Micro-Adjustment Calmness

Goal: avoid overflicking.

Drill:
- place crosshair slightly near bot head
- move small amount only
- fire one clean bullet
- reset

### 4. Anti-Crouch Discipline

For one DM:
- unbind crouch or mentally ban it
- burst + strafe reset only
- crouch is allowed only close range after commitment

### 5. Burst Reset

Rule:

```txt
2-4 bullets → strafe → 2-4 bullets
```

Never turn a long-range duel into 12 bullets unless enemy is trapped.

## Weekly Mechanics Review

| Skill | Rating /10 | Evidence | Correction |
|---|---:|---|---|
| Stop timing |  |  |  |
| Crosshair placement |  |  |  |
| Burst reset |  |  |  |
| Calm micro-adjust |  |  |  |
| Movement under pressure |  |  |  |
