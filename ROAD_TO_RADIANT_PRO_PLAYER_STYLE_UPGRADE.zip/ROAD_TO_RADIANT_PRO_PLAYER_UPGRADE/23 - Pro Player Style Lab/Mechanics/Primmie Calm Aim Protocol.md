# Primmie Calm Aim Protocol

## Purpose

Build calm, repeatable aim that transfers to ranked. This is for days where you are overflicking, panic spraying, or rushing shots.

## Core Rules

1. Burst only when your feet are stable.
2. Crosshair placement before reaction speed.
3. Micro-adjust with calm, not panic.
4. After a missed burst, reset before shooting again.
5. Mid/long range is burst discipline, not spray confidence.

## Range Drill

In Range or practice mode:

```txt
5 minutes: sheriff/guardian one taps
5 minutes: vandal 2-3 bullet bursts
5 minutes: strafe stop + one bullet
5 minutes: medium bot tracking into burst
```

Rules:
- no crouch
- no spray
- only clean shots count
- if you rush, slow down

## Deathmatch Rule Set

Play 1 DM with these restrictions:

- Vandal or Guardian only.
- No crouching.
- No spray longer than 4 bullets.
- Every death: ask “was my crosshair late or my movement bad?”
- Goal is clean kills, not winning DM.

## Ranked Transfer

Pick one ranked rule:

- I will not spray at long range.
- I will hold after planting instead of chasing.
- I will reset after first missed burst.
- I will clear one angle at a time.

## Mistake Signals

You are not in calm aim mode if:

- you crouch instantly
- you keep shooting while moving
- you flick to body then spray
- you wide swing without pre-aim
- your first bullet is not near head level
