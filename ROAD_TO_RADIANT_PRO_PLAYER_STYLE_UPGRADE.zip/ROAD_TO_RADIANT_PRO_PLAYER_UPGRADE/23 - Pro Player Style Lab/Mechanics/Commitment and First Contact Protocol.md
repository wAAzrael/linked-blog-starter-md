# Commitment and First Contact Protocol

## Purpose

Build canezerra-style confident pressure without turning into a ranked thrower.

## First Contact Checklist

Before taking first contact, scan:

```txt
Timing: do I beat enemy setup?
Trade: can teammate trade me?
Escape: do I have Dismiss / TP / smoke / cover?
Angle count: am I exposed to one angle?
Purpose: what value does this fight create?
```

If the fight has no purpose, skip it.

## Commitment Types

### Soft Commit

Goal: info / utility / pressure.

Examples:
- jiggle main for OP info
- show presence then fall
- bait utility
- hold anti-push

### Hard Commit

Goal: kill / entry / break timing.

Examples:
- Reyna Leer swing
- Chamber first contact with TP
- Clove flash/smoke timing fight
- Omen paranoia fight with teammate

### Fake Commit

Goal: force rotation.

Examples:
- make sound, smoke, then leave
- show Leer and fall
- pressure one lane while team hits opposite

## The Commit Rule

> Half-commits lose rounds.

If you go, go with full intention. If the fight becomes bad, reset fully. Do not stand between both decisions.

## Ranked Transfer

For one ranked block, choose one:

- I will take first contact only with a trade/escape.
- I will stop dry peeking after advantage.
- I will call my contact before I swing.
- I will turn enemy repeated timing into a punish.

## Review Questions

- Did I know why I fought?
- Did my death create space or just lose numbers?
- Did I leave after value?
- Did I hesitate and die in the middle?
