# Pro Style Clip Note Template

## Clip

```txt
Player:
Link:
Map:
Agent:
Round state:
```

## What Happened

-

## Why It Worked

| Factor | Evidence |
|---|---|
| Info |  |
| Timing |  |
| Utility |  |
| Trade |  |
| Escape |  |
| Aim/movement |  |

## Principle To Steal

-

## My Safe Ranked Version

-

## Agent Translation

| Agent | How I use it |
|---|---|
| Reyna |  |
| Chamber |  |
| Omen |  |
| Astra |  |
| Clove |  |

## One-Sentence Rule

```txt
When ______, I will ______.
```
