---
type: player-study
player: canezerra
style: committed pressure
status: active
---
# canezerra Style System

## Identity To Steal

canezerra-style play is about **committed confidence**. The value is not only aim. The value is making enemies uncomfortable by taking space with intent, forcing them to react, and converting pressure into kills or map control.

This is not random ego-peeking. The rule is:

```txt
Commit when the fight has a reason. Do not half-commit and die uselessly.
```

## Main Principles

### 1. Pressure Has A Purpose

Every aggressive action needs one of these goals:

- take space
- punish repeated enemy timing
- break a default
- force utility
- create a timing for your team
- isolate a 1v1

If your aggression does none of those, it is ego.

### 2. Commit Fully Or Do Not Go

Bad ranked death:

```txt
I peeked, got scared, half-fought, half-ran, died with no trade.
```

Good committed death:

```txt
I took planned first contact, forced two enemies to look at me, got traded, and opened site.
```

Great committed round:

```txt
I read the enemy timing, fought before they were set, got one, escaped or got traded.
```

### 3. Confidence Comes From Pre-Fight Checks

Before a committed fight, ask:

| Check | Question |
|---|---|
| Timing | Am I early, equal, or late? |
| Trade | Can teammate trade me? |
| Escape | Do I have Dismiss / TP / smoke / cover? |
| Angle count | Am I exposed to one angle or multiple? |
| Enemy pattern | Have they shown this habit before? |

Take the fight only when at least 3/5 are positive.

### 4. Win The Timing Before The Aim Duel

High-mechanics players often look like they aim better because they fight before the enemy is comfortable.

Ways to win timing:
- swing during enemy utility pullout
- re-peek after enemy assumes you fell
- fight when smoke is about to fade
- punish predictable drone/dog/fade prowler timing
- hold the second contact instead of the obvious first contact

## Ranked Rules For You

- Do not call yourself aggressive unless your aggression creates value.
- On Reyna, fight with Leer or teammate pressure, not dry from boredom.
- On Chamber, take first contact only with TP discipline.
- On Omen/Clove, fight through your own smoke timing, not outside your smoke value.
- After a first kill, ask: **can I leave? can I isolate one more? or do I need to stop?**

## Best Agents To Translate This To

### Reyna
- Best copy target because Dismiss lets you commit and reset.
- Your goal is first contact into escape, not first contact into greed.

### Chamber
- Controlled aggression with Rendezvous.
- One kill and vanish is more valuable than ego-holding for a montage.

### Clove
- You can play more aggressive than Omen/Astra because post-death smoke exists, but that does not mean first-death is good.

## DM Mode

Run [[23 - Pro Player Style Lab/Training/Deathmatch Modes - Canezerra Primmie Solada#canezerra DM - Commit And Reset]]

## Review Questions

- Did my aggression have a purpose?
- Did I die in a tradeable spot?
- Did I commit to the fight or hesitate?
- Did I stop after getting value?

## Key Quote

> Confidence is clean only when it creates value.
