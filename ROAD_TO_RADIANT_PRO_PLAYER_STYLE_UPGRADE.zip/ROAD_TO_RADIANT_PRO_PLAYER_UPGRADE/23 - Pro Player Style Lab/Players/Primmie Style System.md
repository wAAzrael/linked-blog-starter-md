---
type: player-study
player: Primmie
style: calm mechanics
status: active
---
# Primmie Style System

## Identity To Steal

Primmie-style play is built around **calm mechanical certainty**. The fight does not look rushed. The crosshair is already close. Movement is small, deliberate, and timed. The shot looks easy because the pre-fight preparation is clean.

## Main Principles

### 1. Calm Crosshair Before Speed

Do not flick first. Place first.

```txt
See target → stabilize crosshair → micro-adjust → fire controlled burst
```

The goal is to make every duel feel like the enemy walked into your crosshair.

### 2. Movement Creates Aim

You do not use movement to look flashy. You use movement to make the shot smaller.

Good movement:
- stops before the burst
- uses A/D to expose only one angle
- resets after whiffing instead of panic spraying
- keeps crosshair at head height during reposition

Bad movement:
- wide swinging without crosshair discipline
- crouching before confirming target
- over-strafing while trying to micro-adjust
- moving because you are nervous

### 3. One Fight, One Intention

Before you peek, decide the fight type.

| Fight Type | Intention |
|---|---|
| Jiggle | Info only, do not commit. |
| Slice peek | Clear one angle. |
| Contact swing | Fight with teammate/trade. |
| Wide swing | Break crosshair placement, only with timing/read. |
| Hold | Let enemy move into crosshair. |

### 4. Minimal Panic

If the first bullets miss:

```txt
Stop shooting → strafe reset → re-place crosshair → burst again
```

Never turn one missed burst into a full emotional spray unless the distance is close enough and the target is committed.

## Ranked Rules For You

- Take fewer lazy wide swings.
- Hold more disciplined off-angles when enemy is forced to clear.
- Stop after your first bad burst instead of spraying instantly.
- In mid/long range, burst 2-4 bullets max, then reset.
- Do not fight while thinking about utility. Decide utility first, then fight.

## Best Agents To Translate This To

### Reyna
- Use Leer to force a predictable swing, then hold calmly.
- After kill, Dismiss only if second enemy can trade.
- Do not Empress and become brain-off. Empress should make your fundamentals faster, not worse.

### Chamber
- Your first bullet has to be premium.
- Hold angles where the enemy must enter your crosshair.
- TP after value, not after greed.

### Omen / Astra / Clove
- Smoke first, then take the fight with a reduced angle.
- Do not die with smoke available because you wanted a dry mechanics test.

## DM Mode

Run [[23 - Pro Player Style Lab/Training/Deathmatch Modes - Canezerra Primmie Solada#Primmie DM - Calm Aim]]

## Review Questions

After every ranked session:

- Did I panic spray at mid/long range?
- Did I move before my crosshair was ready?
- Did I choose my fight type before peeking?
- How many deaths were caused by rushing the shot?

## Key Quote

> Smooth first. Fast second. Deadly third.
