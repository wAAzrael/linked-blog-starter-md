---
type: identity
status: active
---
# Hybrid Style - My Version

## My Goal

Become a controller/flex player with mechanics strong enough to carry rounds, but discipline strong enough to not throw them.

## The Hybrid Formula

```txt
Primmie = calm aim
canezerra = committed pressure
Solada = tempo/read/punish
Me = controller brain + flex mechanics + ranked consistency
```

## What I Steal From Each Player

| Player | What I Steal | What I Avoid |
|---|---|---|
| Primmie | calm crosshair, disciplined movement, clean bursts | becoming too passive while looking for perfect aim |
| canezerra | committed first contact, confidence, pressure | ego-swinging without value |
| Solada | tempo switching, punish habits, ranked carry instinct | chaotic overfighting |

## My Round Identity

### First 20 Seconds

- Identify enemy speed.
- Choose utility plan.
- Avoid useless first death.
- Look for one pattern.

### Mid-Round

- If advantage: slow down and lock the round.
- If disadvantage: create pressure only with timing or utility.
- If enemy repeats: call punish.
- If team is chaotic: simplify with one clear call.

### End-Round

- Play numbers.
- Use smoke/flash/TP/Dismiss for the second fight.
- Do not chase highlight kills.
- Win the round first, clip second.

## My Agent Identity

### Omen
Creative pressure + second-cycle utility.

### Astra
Macro control + team round shaping.

### Clove
Aggressive controller + tempo punisher.

### Reyna
Confidence carry pick + punish bad spacing.

### Chamber
Controlled first contact + anti-rush safety.

## Daily Focus Sentence

> I will take confident fights only when the fight has timing, angle discipline, utility, or trade value.
