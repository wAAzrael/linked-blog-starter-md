---
type: player-study
player: Solada
style: ranked tempo
status: active
---
# Solada Style System

## Identity To Steal

Solada-style notes are about **ranked tempo control**: being mechanically dangerous while constantly testing where the enemy is weak. The style is not just “swing everything.” It is quick adaptation.

```txt
Probe → punish → reset → hit the new weakness
```

## Main Principles

### 1. Find The Weak Player Fast

In ranked, one enemy usually gives you free patterns:

- always re-peeks after contact
- over-rotates on noise
- anchors alone
- never clears deep corner
- burns utility too early
- peeks mid every round

Your job is to identify that player and build rounds around punishing them.

### 2. Tempo Switching

You cannot play one speed all game.

| Round State | Tempo |
|---|---|
| Enemy is scared | Speed up and punish space. |
| Enemy is stacking | Slow down, fake, split. |
| You got first pick | Slow down, force them to make mistake. |
| You lost first player | Speed up only if site weakness is known. |
| Enemy OP is active | Default slower, remove escape, then explode. |

### 3. Mechanics With Chaos Control

Ranked has messy fights. The goal is to stay clean inside chaos.

- isolate one angle even when teammates rush
- do not chase the second kill blind
- use utility to make chaos readable
- if comms are bad, play around minimap and sound
- be the player who gives structure without overcalling

### 4. Abuse Comfort Picks

For you, the biggest Solada translation is **Reyna**.

Reyna in ranked is strongest when you:
- take controlled first fights
- snowball when enemy spacing is bad
- Dismiss from trade pressure
- punish isolated anchors
- refuse unnecessary 50/50 after advantage

## Ranked Rules For You

- First 4 rounds: identify enemy weakest pattern.
- If enemy repeats a timing twice, build a punish round.
- If your team is chaotic, choose simple protocols: hit, trade, plant, post.
- Do not let chaos make your crosshair chaotic.
- Carry by simplifying the round, not by taking every fight.

## Best Agents To Translate This To

### Reyna
- Primary Solada-style translation.
- You should be the player who punishes bad spacing and repeated timings.

### Clove
- Secondary translation because Clove can fight and still smoke after death.
- Use aggression to create round pressure, not to excuse bad first deaths.

### Chamber
- Works if enemy has predictable first-contact routes.
- Do not lurk so far that you cannot convert team timing.

## DM Mode

Run [[23 - Pro Player Style Lab/Training/Deathmatch Modes - Canezerra Primmie Solada#Solada DM - Chaos Control]]

## Review Questions

- Who was the enemy weak link?
- What pattern did I punish?
- Did I change tempo or play one speed all game?
- Did I stay calm in messy fights?

## Key Quote

> Ranked chaos becomes easy when you find the pattern first.
