# Solada VOD Study Template

## VOD Info

```txt
Link:
Agent:
Map:
Round:
```

## What To Watch

### Tempo

- Did he speed up or slow down?
- What enemy weakness was attacked?
- Did he punish a repeated habit?
- How did he handle messy ranked spacing?
- Did he isolate or overfight?

### Carry Pattern

- Which round did he create momentum?
- How did he use utility to make the fight readable?
- Did he leave after value or continue pressure?

### Transfer To Me

| Observation | My Rule |
|---|---|
|  |  |
|  |  |

## Ranked Drill

```txt
For next 3 games, I will:
```
