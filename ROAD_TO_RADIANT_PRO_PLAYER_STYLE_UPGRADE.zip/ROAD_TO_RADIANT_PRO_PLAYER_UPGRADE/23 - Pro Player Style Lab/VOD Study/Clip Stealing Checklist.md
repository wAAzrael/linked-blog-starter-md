# Clip Stealing Checklist

Use this before copying any pro clip.

## Clip Info

```txt
Player:
Agent:
Map:
Round state:
Score/economy:
Clip link:
```

## Conditions Behind The Clip

- What info did the player have?
- What utility created the fight?
- Could teammate trade?
- What enemy habit was punished?
- What escape route existed?
- What happened before the kill?

## Copy Decision

| Question | Answer |
|---|---|
| Can I recreate this in ranked? |  |
| Does it need team coordination? |  |
| Which agent in my pool can use this? |  |
| What is the safe version? |  |
| What is the throw version? |  |

## My Ranked Rule From This Clip

```txt
When ______ happens, I will ______ because ______.
```

## Warning

If you cannot explain why the clip worked, you are not allowed to copy it in ranked.
