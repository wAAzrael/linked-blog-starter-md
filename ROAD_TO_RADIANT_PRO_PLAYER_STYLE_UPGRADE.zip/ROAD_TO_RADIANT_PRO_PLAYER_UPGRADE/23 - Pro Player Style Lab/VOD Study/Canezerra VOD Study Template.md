# canezerra VOD Study Template

## VOD Info

```txt
Link:
Agent:
Map:
Round:
```

## What To Watch

### Pressure

- What space was taken?
- Was the fight early, equal, or late timing?
- Did the pressure force utility/rotation?
- Was the death tradeable?
- Did he leave after value?

### Commitment

- Did he hesitate?
- What made the fight worth taking?
- Was there escape or teammate support?

### Transfer To Me

| Observation | My Rule |
|---|---|
|  |  |
|  |  |

## Ranked Drill

```txt
For next 3 games, I will:
```
