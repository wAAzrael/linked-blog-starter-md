# Primmie VOD Study Template

## VOD Info

```txt
Link:
Agent:
Map:
Round:
```

## What To Watch

### Mechanics

- Was crosshair already close before contact?
- Did he hold or swing?
- How much movement before the shot?
- Did he burst or spray?
- What happened after a missed shot?

### Positioning

- Why was this angle good?
- Did the enemy have to clear something else first?
- Was he exposed to one angle or many?

### Transfer To Me

| Observation | My Rule |
|---|---|
|  |  |
|  |  |

## Ranked Drill

```txt
For next 3 games, I will:
```
