# Mistakes When Copying Mechanical Players

## 1. Copying The Clip, Not The Setup

Bad:
- see highlight swing
- copy swing
- die

Good:
- identify info, timing, utility, trade, escape
- recreate safe condition
- take similar fight only when condition exists

## 2. Changing Sens/Crosshair Too Often

A player is not good because of one setting. Settings help consistency, but changing every day kills consistency.

Rule:

```txt
No sens/crosshair change during a serious ranked week unless there is a real issue.
```

## 3. Thinking Confidence Means Always Swinging

Confidence also means holding, saving, slowing down, and refusing a bad fight.

## 4. Forgetting Your Role

If you are Omen/Astra/Clove, dying first with all utility is not pro-style. It is wasted value.

## 5. Overheating After One Kill

Mechanical players often look like they can kill everyone. But the repeatable skill is knowing when the second fight is actually good.

## 6. Watching Highlights Instead Of Full Rounds

Highlights remove context. Full rounds teach why the highlight became possible.

## Correction Table

| Bad Copy Habit | Real Pro Principle |
|---|---|
| Wide swing everything | Swing with timing/value. |
| Spray every duel | Burst/reset. |
| Chase second kill | Escape/reposition after value. |
| Lurk every round | Lurk with team timing. |
| Dry entry as controller | Utility creates fight. |
| Blame aim | Review fight quality. |
