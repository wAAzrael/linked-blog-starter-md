# Positioning

## Pro Definition

Positioning is the ability to make the next decision easier for your team while making the enemy decision harder.

## Checklist

- Play positions with exit or trade
- Avoid dead corners with no utility
- Hold crossfires not solo hero angles
- Change position after contact
- Position for next objective not current comfort

## In-Game Questions

- What do we know for sure?
- What are we assuming?
- What space is currently free?
- Where is the spike safest?
- How do we lose this round if we get careless?

## Common Mistakes

| Mistake | Why it loses | Fix |
|---|---|---|
| Acting on fake info | Enemy pulls rotation for free | Wait for spike, bodies, or key utility |
| Fighting without purpose | Numbers get thrown | Link fight to space/objective |
| No verbal update | Teammates rotate late or wrong | Call space, utility, and intention |

## Review Log

| Date | Map | Round | Decision | Better decision |
|---|---|---:|---|---|
|  |  |  |  |  |
