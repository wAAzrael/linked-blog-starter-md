# Mid-Rounding

## Pro Definition

Mid-Rounding is the ability to make the next decision easier for your team while making the enemy decision harder.

## Checklist

- Ask what info is missing
- Identify weak site/rotator
- Call group/fake/re-hit clearly
- Preserve final smoke if possible
- After pick, slow and convert

## In-Game Questions

- What do we know for sure?
- What are we assuming?
- What space is currently free?
- Where is the spike safest?
- How do we lose this round if we get careless?

## Common Mistakes

| Mistake | Why it loses | Fix |
|---|---|---|
| Acting on fake info | Enemy pulls rotation for free | Wait for spike, bodies, or key utility |
| Fighting without purpose | Numbers get thrown | Link fight to space/objective |
| No verbal update | Teammates rotate late or wrong | Call space, utility, and intention |

## Review Log

| Date | Map | Round | Decision | Better decision |
|---|---|---:|---|---|
|  |  |  |  |  |
