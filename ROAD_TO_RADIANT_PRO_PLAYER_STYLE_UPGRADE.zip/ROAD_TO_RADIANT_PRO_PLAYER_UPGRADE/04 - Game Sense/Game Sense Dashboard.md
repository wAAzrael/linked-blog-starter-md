# Game Sense Dashboard

## Core Pages

- [[04 - Game Sense/Round Reading]]
- [[04 - Game Sense/Map Awareness]]
- [[04 - Game Sense/Timing]]
- [[04 - Game Sense/Positioning]]
- [[04 - Game Sense/Trading]]
- [[04 - Game Sense/Rotations]]
- [[04 - Game Sense/Economy]]
- [[04 - Game Sense/Clutching]]
- [[04 - Game Sense/Mid-Rounding]]
- [[04 - Game Sense/Anti-Autopilot]]

## Radiant Game Sense Loop

```txt
Info → Pattern → Win condition → Protocol → Execution → Review
```

## Between-Round Call

1. What did they do last round?
2. What will they repeat?
3. What will they change?
4. What is my first 20 seconds job?
5. What utility must I preserve?
