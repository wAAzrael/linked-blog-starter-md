# Rotations

## Pro Definition

Rotations is the ability to make the next decision easier for your team while making the enemy decision harder.

## Checklist

- Rotate on spike/multiple bodies/key utility
- Anchor until info is real
- Call what space you give up
- Fake pressure before leaving sometimes
- Never rotate because you are bored

## In-Game Questions

- What do we know for sure?
- What are we assuming?
- What space is currently free?
- Where is the spike safest?
- How do we lose this round if we get careless?

## Common Mistakes

| Mistake | Why it loses | Fix |
|---|---|---|
| Acting on fake info | Enemy pulls rotation for free | Wait for spike, bodies, or key utility |
| Fighting without purpose | Numbers get thrown | Link fight to space/objective |
| No verbal update | Teammates rotate late or wrong | Call space, utility, and intention |

## Review Log

| Date | Map | Round | Decision | Better decision |
|---|---|---:|---|---|
|  |  |  |  |  |
