# Clove Mistakes

## Repeated Mistakes To Watch

- Playing like a duelist but giving no smoke structure.
- Dying before using important smoke/meddle.
- Ulting where team cannot trade revive.
- Smoking after teammates already crossed/died.
- Overhealing or chasing instead of resetting numbers.

## Correction System

When a mistake happens, do not write “bad play.” Write the trigger.

```txt
Trigger:
What I did:
Why it lost value:
Correct protocol next time:
```

## Mistake Table

| Date | Map | Side | Round | Mistake | Correction |
|---|---|---|---:|---|---|
|  |  |  |  |  |  |
