---
type: agent_playbook
agent: Clove
status: active
updated: 2026-07-04
---
# Clove Playbook

## Identity

**Role:** Tempo controller / ranked fighter

**Main focus:** Smoke with contact, Meddle damage, post-death value

A pro-level Clove player is not judged by highlight clips. They are judged by round conversion: first contact quality, utility timing, survival value, and how consistently the team can play around their decisions.

## Pick Conditions

### Pick Clove when
- The map supports your job on this agent.
- Your team composition still has basic structure.
- Your mental state matches the agent responsibility.
- You know your first 20 seconds on both attack and defense.

### Avoid Clove when
- You are picking from tilt.
- You cannot name your utility plan.
- The team needs a different role more urgently.
- You are likely to play selfishly and break trading structure.

## Best Maps From Current Pool

- Sunset
- Ascent
- Haven
- Split
- Summit

## Attack Protocol

### First 20 seconds
- Identify enemy default speed.
- Decide whether your job is contact, support, lurk deny, or spike protection.
- Use utility only when it creates space, denies info, or converts a timing.
- Avoid dying before the first real decision of the round.

### Mid-round
- If your team gets first pick: slow down, group, and force trades.
- If your team loses first pick: find map space, fake pressure, or create a numbers-isolated fight.
- Preserve one key tool for plant/post-plant whenever possible.

### Late round
- Play numbers, not ego.
- Communicate exact utility remaining.
- Take positions that create crossfire, not five players in one lane.

## Defense Protocol

### First contact
- Your job is not always to kill. Your job is to get value and stay useful.
- If pressured, call count + utility + whether you can hold.
- Do not rotate unless info is real.

### Mid-round
- Track enemy repeat pattern.
- Reposition after being seen.
- Save utility for retake if the site is likely to be hit late.

### Retake
- Group before contact.
- Clear close first.
- Use utility to isolate one fight or deny plant/post-plant positions.

## Agent-Specific Rules

- Your smoke value is strongest when tied to tempo and trade timing.
- Meddle before the fight, not after everyone already swung.
- Post-death smoke is not an excuse to die early for free.
- Pick Me Up is value only if the heal lets you take the next space safely.
- Not Dead Yet should be used for objective conversion, not revenge ego.

## Map Cheat Sheet

| Map | Job |
|---|---|
| Ascent | Ruse Heaven/Tree or Market/CT with tempo. Meddle close pockets before contact. Ult only when team can trade revive. |
| Breeze | Fight with team through smokes; Meddle common close pockets. Keep Ruse for re-clear or plant safety. |
| Haven | Tempo controller for ranked; smoke isolated site, fight second wave, use ult for plant/retake trades. |
| Lotus | Fast tempo hits; Meddle close Lotus pockets and Ruse to isolate door/CT retakes. |
| Split | Fast Ruse through chokes, Meddle close corners. Great if you fight with first/second contact and still have post-death smoke value. |
| Sunset | Ruse B Market/CT, Meddle tight B Main or A Main pockets. Post-death smoke is useful in messy ranked retakes. |
| Summit | Great for early ranked adaptation: Ruse the most dangerous wall gap, Meddle close fights, and keep fighting with trade protocol. |

## Review Prompts

- Did I get value before dying?
- Did my utility create a timing or was it automatic?
- Did I play my role or drift into random fights?
- Did I communicate my intention before contact?
- Did I repeat a mistake from last session?
