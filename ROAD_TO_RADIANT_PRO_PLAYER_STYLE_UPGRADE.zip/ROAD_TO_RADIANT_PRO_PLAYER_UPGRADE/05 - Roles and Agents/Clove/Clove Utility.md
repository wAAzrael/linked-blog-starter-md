# Clove Utility

## Utility Philosophy

Utility is not decoration. Utility must do at least one of these:

1. Create safe space.
2. Deny information.
3. Isolate a fight.
4. Delay a hit.
5. Secure spike plant/defuse.
6. Force enemy movement into a crossfire.

## Utility Quality Checklist

| Question | Yes/No |
|---|---|
| Did the utility match the team's timing? |  |
| Did it create a fight advantage? |  |
| Did it deny an important angle/info path? |  |
| Did it preserve value for the second contact? |  |
| Did I communicate it? |  |

## Map Utility Notes

### Ascent

- Ruse Heaven/Tree or Market/CT with tempo. Meddle close pockets before contact. Ult only when team can trade revive.
- Add screenshots/lineups here after custom testing.

### Breeze

- Fight with team through smokes; Meddle common close pockets. Keep Ruse for re-clear or plant safety.
- Add screenshots/lineups here after custom testing.

### Haven

- Tempo controller for ranked; smoke isolated site, fight second wave, use ult for plant/retake trades.
- Add screenshots/lineups here after custom testing.

### Lotus

- Fast tempo hits; Meddle close Lotus pockets and Ruse to isolate door/CT retakes.
- Add screenshots/lineups here after custom testing.

### Split

- Fast Ruse through chokes, Meddle close corners. Great if you fight with first/second contact and still have post-death smoke value.
- Add screenshots/lineups here after custom testing.

### Sunset

- Ruse B Market/CT, Meddle tight B Main or A Main pockets. Post-death smoke is useful in messy ranked retakes.
- Add screenshots/lineups here after custom testing.

### Summit

- Great for early ranked adaptation: Ruse the most dangerous wall gap, Meddle close fights, and keep fighting with trade protocol.
- Add screenshots/lineups here after custom testing.


## Utility Mistake Log

| Date | Map | Utility | Mistake | Correction |
|---|---|---|---|---|
|  |  |  |  |  |
