# Controller Fundamentals

## Controller Identity

Controller is not “smoke guy.” Controller is the player who controls the enemy’s information, timings, and comfort.

## Smoke Quality

A good smoke has a reason:

| Reason | Example |
|---|---|
| Deny info | Block early Mid/A Main/B Main vision. |
| Create crossing | Let team pass a dangerous long angle. |
| Isolate fight | Split site so entry fights one side first. |
| Delay | Stop rush timing or retake timing. |
| Force movement | Make enemies swing or reposition into utility. |

## Bad Smoke Signs

- You smoke instantly every round with no pressure.
- Your smoke helps enemies hide.
- Your smoke lands after teammates already died.
- You use both smokes early and have no late-round value.
- You never tell teammates what your smoke is for.

## Controller Round Cycle

### Buy phase
- Identify enemy economy.
- Choose first smoke purpose.
- Decide what utility must be preserved.
- Tell team what timing you support.

### Early round
- Deny info or support map control.
- Do not die before second-cycle value.
- Track enemy utility and rotations.

### Mid-round
- Call regroup/fake/re-hit if information appears.
- Use smoke to make the next fight unfair.
- Keep spike path safe.

### Late round
- Smoke final choke.
- Play post-plant crossfire.
- Communicate smoke fade timing.

## Controller Comms

Use short comms:

```txt
Smoking Heaven now.
Smoke fading 3.
I have one smoke for retake.
No smoke for plant.
Wait my Paranoia.
I can delay 5 seconds.
```
