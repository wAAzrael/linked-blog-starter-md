---
type: agent_playbook
agent: Reyna
status: active
updated: 2026-07-04
---
# Reyna Playbook

## Identity

**Role:** Duelist / fight converter

**Main focus:** First-contact pressure, safe Dismiss, snowball discipline

A pro-level Reyna player is not judged by highlight clips. They are judged by round conversion: first contact quality, utility timing, survival value, and how consistently the team can play around their decisions.

## Pick Conditions

### Pick Reyna when
- The map supports your job on this agent.
- Your team composition still has basic structure.
- Your mental state matches the agent responsibility.
- You know your first 20 seconds on both attack and defense.

### Avoid Reyna when
- You are picking from tilt.
- You cannot name your utility plan.
- The team needs a different role more urgently.
- You are likely to play selfishly and break trading structure.

## Best Maps From Current Pool

- Ascent
- Split
- Sunset
- Haven
- Breeze

## Attack Protocol

### First 20 seconds
- Identify enemy default speed.
- Decide whether your job is contact, support, lurk deny, or spike protection.
- Use utility only when it creates space, denies info, or converts a timing.
- Avoid dying before the first real decision of the round.

### Mid-round
- If your team gets first pick: slow down, group, and force trades.
- If your team loses first pick: find map space, fake pressure, or create a numbers-isolated fight.
- Preserve one key tool for plant/post-plant whenever possible.

### Late round
- Play numbers, not ego.
- Communicate exact utility remaining.
- Take positions that create crossfire, not five players in one lane.

## Defense Protocol

### First contact
- Your job is not always to kill. Your job is to get value and stay useful.
- If pressured, call count + utility + whether you can hold.
- Do not rotate unless info is real.

### Mid-round
- Track enemy repeat pattern.
- Reposition after being seen.
- Save utility for retake if the site is likely to be hit late.

### Retake
- Group before contact.
- Clear close first.
- Use utility to isolate one fight or deny plant/post-plant positions.

## Agent-Specific Rules

- Leer must create a real swing timing for you or team.
- Dismiss after first pick into safety unless the next fight is guaranteed isolated.
- Do not overheat after one kill; your job is conversion, not montage.
- Heal only when safe; do not stare at orb while exposed.
- If your team needs entry, be first contact with a trade path. If not, be second contact and punish.

## Map Cheat Sheet

| Map | Job |
|---|---|
| Ascent | Leer for Mid/Cat or A Main entry; Dismiss back into traded space, not deeper into site alone. |
| Breeze | Only take first contact with a trade path. Leer high/wide to break long angle crosshair placement. |
| Haven | Great for A Short/Garage fights. Do not hard lurk every round because Haven needs pressure across three lanes. |
| Lotus | Useful for A Main/C Main first fights. Dismiss back after pick; do not Dismiss through door into unknown stacks. |
| Split | Leer through Mid/A Main/B Main chokes. Do not be the only player taking Mid without support. |
| Sunset | Strong for B Main/Mid fights with Leer. Dismiss to safe angle; avoid overhealing in exposed lane. |
| Summit | Leer through new wall gaps to break angle holders. Do not Dismiss into unscouted wall-created pockets. |

## Review Prompts

- Did I get value before dying?
- Did my utility create a timing or was it automatic?
- Did I play my role or drift into random fights?
- Did I communicate my intention before contact?
- Did I repeat a mistake from last session?
