# Reyna Mistakes

## Repeated Mistakes To Watch

- Leer from a spot where nobody can swing.
- Dismiss deeper into unknown space.
- Taking first duel without trade path.
- Lurking every round and leaving team without entry.
- Overheating after opening kill and throwing advantage.

## Correction System

When a mistake happens, do not write “bad play.” Write the trigger.

```txt
Trigger:
What I did:
Why it lost value:
Correct protocol next time:
```

## Mistake Table

| Date | Map | Side | Round | Mistake | Correction |
|---|---|---|---:|---|---|
|  |  |  |  |  |  |
