# Reyna Utility

## Utility Philosophy

Utility is not decoration. Utility must do at least one of these:

1. Create safe space.
2. Deny information.
3. Isolate a fight.
4. Delay a hit.
5. Secure spike plant/defuse.
6. Force enemy movement into a crossfire.

## Utility Quality Checklist

| Question | Yes/No |
|---|---|
| Did the utility match the team's timing? |  |
| Did it create a fight advantage? |  |
| Did it deny an important angle/info path? |  |
| Did it preserve value for the second contact? |  |
| Did I communicate it? |  |

## Map Utility Notes

### Ascent

- Leer for Mid/Cat or A Main entry; Dismiss back into traded space, not deeper into site alone.
- Add screenshots/lineups here after custom testing.

### Breeze

- Only take first contact with a trade path. Leer high/wide to break long angle crosshair placement.
- Add screenshots/lineups here after custom testing.

### Haven

- Great for A Short/Garage fights. Do not hard lurk every round because Haven needs pressure across three lanes.
- Add screenshots/lineups here after custom testing.

### Lotus

- Useful for A Main/C Main first fights. Dismiss back after pick; do not Dismiss through door into unknown stacks.
- Add screenshots/lineups here after custom testing.

### Split

- Leer through Mid/A Main/B Main chokes. Do not be the only player taking Mid without support.
- Add screenshots/lineups here after custom testing.

### Sunset

- Strong for B Main/Mid fights with Leer. Dismiss to safe angle; avoid overhealing in exposed lane.
- Add screenshots/lineups here after custom testing.

### Summit

- Leer through new wall gaps to break angle holders. Do not Dismiss into unscouted wall-created pockets.
- Add screenshots/lineups here after custom testing.


## Utility Mistake Log

| Date | Map | Utility | Mistake | Correction |
|---|---|---|---|---|
|  |  |  |  |  |
