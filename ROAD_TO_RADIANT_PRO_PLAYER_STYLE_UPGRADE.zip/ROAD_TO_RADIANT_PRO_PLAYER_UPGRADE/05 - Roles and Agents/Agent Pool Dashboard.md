# Agent Pool Dashboard

## Core Pool

- [[05 - Roles and Agents/Omen/Omen Playbook]]
- [[05 - Roles and Agents/Astra/Astra Playbook]]
- [[05 - Roles and Agents/Clove/Clove Playbook]]
- [[05 - Roles and Agents/Reyna/Reyna Playbook]]
- [[05 - Roles and Agents/Chamber/Chamber Playbook]]

## Pick Priority

1. Fill correct role first.
2. Pick comfort only if the team structure is not destroyed.
3. Do not lock Duelist because of tilt.
4. Do not pick controller and then play without smoke discipline.
5. Pick Chamber when flank/pick value is more important than another duelist.

## Agent Review Loop

For every agent, track:
- first 20 seconds plan,
- utility value,
- first death quality,
- post-plant/retake value,
- repeated mistake.
