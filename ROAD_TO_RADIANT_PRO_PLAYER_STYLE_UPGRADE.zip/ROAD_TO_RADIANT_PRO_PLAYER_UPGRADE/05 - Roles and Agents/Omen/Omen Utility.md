# Omen Utility

## Utility Philosophy

Utility is not decoration. Utility must do at least one of these:

1. Create safe space.
2. Deny information.
3. Isolate a fight.
4. Delay a hit.
5. Secure spike plant/defuse.
6. Force enemy movement into a crossfire.

## Utility Quality Checklist

| Question | Yes/No |
|---|---|
| Did the utility match the team's timing? |  |
| Did it create a fight advantage? |  |
| Did it deny an important angle/info path? |  |
| Did it preserve value for the second contact? |  |
| Did I communicate it? |  |

## Map Utility Notes

### Ascent

- Delay Top Mid smoke until Mid players are ready; Paranoia A Main/Tree or B Lane; save a smoke for post-plant or retake.
- Add screenshots/lineups here after custom testing.

### Breeze

- Smoke cross angles and use Paranoia for grouped entries. Do not waste both smokes before spike crosses the danger line.
- Add screenshots/lineups here after custom testing.

### Haven

- Smoke A Heaven/CT, Garage/Window control, Paranoia A Short/Garage/C entry. TP after contact for off-angles.
- Add screenshots/lineups here after custom testing.

### Lotus

- Paranoia through tight lanes/door areas, smoke Heaven/CT-style lines, TP into off-angle only after teammates force eyes away.
- Add screenshots/lineups here after custom testing.

### Split

- Smoke Mid/Vent/Mail, Paranoia through A Main/B Main tight lanes. One-way-style smokes are high value if rehearsed.
- Add screenshots/lineups here after custom testing.

### Sunset

- Smoke Market/CT or A Heaven/Link, Paranoia B Main/Market crunch. Use TP only after utility breaks crosshair placement.
- Add screenshots/lineups here after custom testing.

### Summit

- Use smokes to isolate new wall gaps. Paranoia through compressed wall-created corridors. Verify one-ways before adding them to the live library.
- Add screenshots/lineups here after custom testing.


## Utility Mistake Log

| Date | Map | Utility | Mistake | Correction |
|---|---|---|---|---|
|  |  |  |  |  |
