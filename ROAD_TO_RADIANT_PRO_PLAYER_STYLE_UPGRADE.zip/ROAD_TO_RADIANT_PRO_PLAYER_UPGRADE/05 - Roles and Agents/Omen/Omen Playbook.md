---
type: agent_playbook
agent: Omen
status: active
updated: 2026-07-04
---
# Omen Playbook

## Identity

**Role:** Flexible controller / playmaker

**Main focus:** Smoke timing, Paranoia impact, second-cycle survival

A pro-level Omen player is not judged by highlight clips. They are judged by round conversion: first contact quality, utility timing, survival value, and how consistently the team can play around their decisions.

## Pick Conditions

### Pick Omen when
- The map supports your job on this agent.
- Your team composition still has basic structure.
- Your mental state matches the agent responsibility.
- You know your first 20 seconds on both attack and defense.

### Avoid Omen when
- You are picking from tilt.
- You cannot name your utility plan.
- The team needs a different role more urgently.
- You are likely to play selfishly and break trading structure.

## Best Maps From Current Pool

- Ascent
- Haven
- Split
- Sunset
- Lotus

## Attack Protocol

### First 20 seconds
- Identify enemy default speed.
- Decide whether your job is contact, support, lurk deny, or spike protection.
- Use utility only when it creates space, denies info, or converts a timing.
- Avoid dying before the first real decision of the round.

### Mid-round
- If your team gets first pick: slow down, group, and force trades.
- If your team loses first pick: find map space, fake pressure, or create a numbers-isolated fight.
- Preserve one key tool for plant/post-plant whenever possible.

### Late round
- Play numbers, not ego.
- Communicate exact utility remaining.
- Take positions that create crossfire, not five players in one lane.

## Defense Protocol

### First contact
- Your job is not always to kill. Your job is to get value and stay useful.
- If pressured, call count + utility + whether you can hold.
- Do not rotate unless info is real.

### Mid-round
- Track enemy repeat pattern.
- Reposition after being seen.
- Save utility for retake if the site is likely to be hit late.

### Retake
- Group before contact.
- Clear close first.
- Use utility to isolate one fight or deny plant/post-plant positions.

## Agent-Specific Rules

- Never smoke instantly without a teammate timing unless it denies urgent info.
- Paranoia should win a lane, not just look useful.
- Shrouded Step after pressure breaks crosshair placement, not as a raw gamble.
- Keep one smoke for the second phase whenever the hit is not immediate.
- On defense, smoke to split the execute wave, not to hide your own panic.

## Map Cheat Sheet

| Map | Job |
|---|---|
| Ascent | Delay Top Mid smoke until Mid players are ready; Paranoia A Main/Tree or B Lane; save a smoke for post-plant or retake. |
| Breeze | Smoke cross angles and use Paranoia for grouped entries. Do not waste both smokes before spike crosses the danger line. |
| Haven | Smoke A Heaven/CT, Garage/Window control, Paranoia A Short/Garage/C entry. TP after contact for off-angles. |
| Lotus | Paranoia through tight lanes/door areas, smoke Heaven/CT-style lines, TP into off-angle only after teammates force eyes away. |
| Split | Smoke Mid/Vent/Mail, Paranoia through A Main/B Main tight lanes. One-way-style smokes are high value if rehearsed. |
| Sunset | Smoke Market/CT or A Heaven/Link, Paranoia B Main/Market crunch. Use TP only after utility breaks crosshair placement. |
| Summit | Use smokes to isolate new wall gaps. Paranoia through compressed wall-created corridors. Verify one-ways before adding them to the live library. |

## Review Prompts

- Did I get value before dying?
- Did my utility create a timing or was it automatic?
- Did I play my role or drift into random fights?
- Did I communicate my intention before contact?
- Did I repeat a mistake from last session?
