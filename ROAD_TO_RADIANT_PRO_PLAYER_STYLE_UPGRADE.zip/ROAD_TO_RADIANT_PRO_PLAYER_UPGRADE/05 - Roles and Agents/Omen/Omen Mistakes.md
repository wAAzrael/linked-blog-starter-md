# Omen Mistakes

## Repeated Mistakes To Watch

- Smoking because the round started, not because the team needs a timing.
- Paranoia too early before teammates can swing.
- TP into a position with no trade or escape.
- Dying before second smoke cycle.
- Retake smoking the wrong side and helping attackers.

## Correction System

When a mistake happens, do not write “bad play.” Write the trigger.

```txt
Trigger:
What I did:
Why it lost value:
Correct protocol next time:
```

## Mistake Table

| Date | Map | Side | Round | Mistake | Correction |
|---|---|---|---:|---|---|
|  |  |  |  |  |  |
