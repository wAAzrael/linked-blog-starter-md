---
type: agent_playbook
agent: Astra
status: active
updated: 2026-07-04
---
# Astra Playbook

## Identity

**Role:** Global controller / set-play brain

**Main focus:** Star planning, recall fakes, plant/defuse punishment

A pro-level Astra player is not judged by highlight clips. They are judged by round conversion: first contact quality, utility timing, survival value, and how consistently the team can play around their decisions.

## Pick Conditions

### Pick Astra when
- The map supports your job on this agent.
- Your team composition still has basic structure.
- Your mental state matches the agent responsibility.
- You know your first 20 seconds on both attack and defense.

### Avoid Astra when
- You are picking from tilt.
- You cannot name your utility plan.
- The team needs a different role more urgently.
- You are likely to play selfishly and break trading structure.

## Best Maps From Current Pool

- Lotus
- Haven
- Ascent
- Split
- Sunset

## Attack Protocol

### First 20 seconds
- Identify enemy default speed.
- Decide whether your job is contact, support, lurk deny, or spike protection.
- Use utility only when it creates space, denies info, or converts a timing.
- Avoid dying before the first real decision of the round.

### Mid-round
- If your team gets first pick: slow down, group, and force trades.
- If your team loses first pick: find map space, fake pressure, or create a numbers-isolated fight.
- Preserve one key tool for plant/post-plant whenever possible.

### Late round
- Play numbers, not ego.
- Communicate exact utility remaining.
- Take positions that create crossfire, not five players in one lane.

## Defense Protocol

### First contact
- Your job is not always to kill. Your job is to get value and stay useful.
- If pressured, call count + utility + whether you can hold.
- Do not rotate unless info is real.

### Mid-round
- Track enemy repeat pattern.
- Reposition after being seen.
- Save utility for retake if the site is likely to be hit late.

### Retake
- Group before contact.
- Clear close first.
- Use utility to isolate one fight or deny plant/post-plant positions.

## Agent-Specific Rules

- Place stars with a round plan, not random decoration.
- Recall stars to create fake pressure and refresh tempo.
- Pull/stun when teammates can swing or when enemy is planting/defusing.
- Avoid being stuck in Astral Form during first contact.
- Communicate star purpose before the round starts.

## Map Cheat Sheet

| Map | Job |
|---|---|
| Ascent | Star Mid choke, Tree, Market/Lane. Use recalls to fake presence, pull default plant or defuse, stun Tree/Market swings. |
| Breeze | Global stars slow extremes; pull/stun plant zones and choke re-swings. Recall early star to fake map pressure. |
| Haven | Stars across three sites for global slow. Pull A default/C plant, stun Garage/B entries, recall to fake rotations. |
| Lotus | Excellent: stars for A Rubble, C Main, B choke, plant/defuse. Recalls create fake door pressure. |
| Split | Stars for Mid choke, Ramps, Heaven, plant spots. Pulls/stuns punish narrow chokepoint swings. |
| Sunset | Star B Main/Market/Mid. Pull default plant/defuse and stun Market swings. |
| Summit | Global stars are ideal for wall-state chaos: place stars on common wall gaps, plant zones, and retake paths; recall to fake a wall-side hit. |

## Review Prompts

- Did I get value before dying?
- Did my utility create a timing or was it automatic?
- Did I play my role or drift into random fights?
- Did I communicate my intention before contact?
- Did I repeat a mistake from last session?
