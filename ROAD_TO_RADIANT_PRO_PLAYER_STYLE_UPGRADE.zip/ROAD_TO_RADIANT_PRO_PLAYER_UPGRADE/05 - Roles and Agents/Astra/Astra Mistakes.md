# Astra Mistakes

## Repeated Mistakes To Watch

- Entering Astral Form while contact is possible.
- Placing all stars on one plan and having no mid-round value.
- Pull/stun with no teammate timing.
- Forgetting recalls as fake pressure.
- Playing too far from spike/team in ranked chaos.

## Correction System

When a mistake happens, do not write “bad play.” Write the trigger.

```txt
Trigger:
What I did:
Why it lost value:
Correct protocol next time:
```

## Mistake Table

| Date | Map | Side | Round | Mistake | Correction |
|---|---|---|---:|---|---|
|  |  |  |  |  |  |
