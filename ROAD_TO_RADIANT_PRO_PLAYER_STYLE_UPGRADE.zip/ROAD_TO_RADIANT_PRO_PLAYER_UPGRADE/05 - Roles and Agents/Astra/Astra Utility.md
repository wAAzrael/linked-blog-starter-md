# Astra Utility

## Utility Philosophy

Utility is not decoration. Utility must do at least one of these:

1. Create safe space.
2. Deny information.
3. Isolate a fight.
4. Delay a hit.
5. Secure spike plant/defuse.
6. Force enemy movement into a crossfire.

## Utility Quality Checklist

| Question | Yes/No |
|---|---|
| Did the utility match the team's timing? |  |
| Did it create a fight advantage? |  |
| Did it deny an important angle/info path? |  |
| Did it preserve value for the second contact? |  |
| Did I communicate it? |  |

## Map Utility Notes

### Ascent

- Star Mid choke, Tree, Market/Lane. Use recalls to fake presence, pull default plant or defuse, stun Tree/Market swings.
- Add screenshots/lineups here after custom testing.

### Breeze

- Global stars slow extremes; pull/stun plant zones and choke re-swings. Recall early star to fake map pressure.
- Add screenshots/lineups here after custom testing.

### Haven

- Stars across three sites for global slow. Pull A default/C plant, stun Garage/B entries, recall to fake rotations.
- Add screenshots/lineups here after custom testing.

### Lotus

- Excellent: stars for A Rubble, C Main, B choke, plant/defuse. Recalls create fake door pressure.
- Add screenshots/lineups here after custom testing.

### Split

- Stars for Mid choke, Ramps, Heaven, plant spots. Pulls/stuns punish narrow chokepoint swings.
- Add screenshots/lineups here after custom testing.

### Sunset

- Star B Main/Market/Mid. Pull default plant/defuse and stun Market swings.
- Add screenshots/lineups here after custom testing.

### Summit

- Global stars are ideal for wall-state chaos: place stars on common wall gaps, plant zones, and retake paths; recall to fake a wall-side hit.
- Add screenshots/lineups here after custom testing.


## Utility Mistake Log

| Date | Map | Utility | Mistake | Correction |
|---|---|---|---|---|
|  |  |  |  |  |
