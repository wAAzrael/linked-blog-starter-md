# Chamber Utility

## Utility Philosophy

Utility is not decoration. Utility must do at least one of these:

1. Create safe space.
2. Deny information.
3. Isolate a fight.
4. Delay a hit.
5. Secure spike plant/defuse.
6. Force enemy movement into a crossfire.

## Utility Quality Checklist

| Question | Yes/No |
|---|---|
| Did the utility match the team's timing? |  |
| Did it create a fight advantage? |  |
| Did it deny an important angle/info path? |  |
| Did it preserve value for the second contact? |  |
| Did I communicate it? |  |

## Map Utility Notes

### Ascent

- Rendezvous for A Main/B Main early pick or Market OP timing; Trademark Cat/B Main flank depending on default.
- Add screenshots/lineups here after custom testing.

### Breeze

- OP/value rifle angles with Rendezvous. Trademark lurk/flank because rotations are long and late lurks decide rounds.
- Add screenshots/lineups here after custom testing.

### Haven

- Trademark Garage/flank. Rendezvous for C Long/A Long opening pick and safe anchor escape.
- Add screenshots/lineups here after custom testing.

### Lotus

- Trap flank/door timings. Rendezvous enables A/C extremity pick and safe fall back.
- Add screenshots/lineups here after custom testing.

### Split

- Rendezvous for Ramp/B Main pick; Trademark flank/Mid. OP angles are strong but must reposition after first shot.
- Add screenshots/lineups here after custom testing.

### Sunset

- Trademark Mid/B flank. Rendezvous for B Main or A Main pick, then fall into retake/setup.
- Add screenshots/lineups here after custom testing.

### Summit

- Trademark the most common wall-change flank. Rendezvous lets you test aggressive angles safely while learning the map.
- Add screenshots/lineups here after custom testing.


## Utility Mistake Log

| Date | Map | Utility | Mistake | Correction |
|---|---|---|---|---|
|  |  |  |  |  |
