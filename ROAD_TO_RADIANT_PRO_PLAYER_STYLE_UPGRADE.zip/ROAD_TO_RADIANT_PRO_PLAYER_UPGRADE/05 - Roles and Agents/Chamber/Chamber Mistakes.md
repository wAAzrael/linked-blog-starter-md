# Chamber Mistakes

## Repeated Mistakes To Watch

- Rendezvous too far or blocked by bad geometry.
- Trap placed where it gives no useful timing info.
- Re-peeking same OP angle after being seen.
- Lurking too slow while team loses spike fight.
- Saving weapons instead of using pick pressure to win key rounds.

## Correction System

When a mistake happens, do not write “bad play.” Write the trigger.

```txt
Trigger:
What I did:
Why it lost value:
Correct protocol next time:
```

## Mistake Table

| Date | Map | Side | Round | Mistake | Correction |
|---|---|---|---:|---|---|
|  |  |  |  |  |  |
