---
type: agent_playbook
agent: Chamber
status: active
updated: 2026-07-04
---
# Chamber Playbook

## Identity

**Role:** Sentinel-flex / pick and flank control

**Main focus:** Safe opening angles, Rendezvous discipline, Trademark value

A pro-level Chamber player is not judged by highlight clips. They are judged by round conversion: first contact quality, utility timing, survival value, and how consistently the team can play around their decisions.

## Pick Conditions

### Pick Chamber when
- The map supports your job on this agent.
- Your team composition still has basic structure.
- Your mental state matches the agent responsibility.
- You know your first 20 seconds on both attack and defense.

### Avoid Chamber when
- You are picking from tilt.
- You cannot name your utility plan.
- The team needs a different role more urgently.
- You are likely to play selfishly and break trading structure.

## Best Maps From Current Pool

- Breeze
- Haven
- Ascent
- Sunset
- Lotus

## Attack Protocol

### First 20 seconds
- Identify enemy default speed.
- Decide whether your job is contact, support, lurk deny, or spike protection.
- Use utility only when it creates space, denies info, or converts a timing.
- Avoid dying before the first real decision of the round.

### Mid-round
- If your team gets first pick: slow down, group, and force trades.
- If your team loses first pick: find map space, fake pressure, or create a numbers-isolated fight.
- Preserve one key tool for plant/post-plant whenever possible.

### Late round
- Play numbers, not ego.
- Communicate exact utility remaining.
- Take positions that create crossfire, not five players in one lane.

## Defense Protocol

### First contact
- Your job is not always to kill. Your job is to get value and stay useful.
- If pressured, call count + utility + whether you can hold.
- Do not rotate unless info is real.

### Mid-round
- Track enemy repeat pattern.
- Reposition after being seen.
- Save utility for retake if the site is likely to be hit late.

### Retake
- Group before contact.
- Clear close first.
- Use utility to isolate one fight or deny plant/post-plant positions.

## Agent-Specific Rules

- Rendezvous must be placed before greed, not after panic.
- Trademark protects the round plan; do not forget flank value.
- Tour de Force rounds need teammates to play off the slow/pick, not watch you solo.
- After first shot/contact, reposition; repeated angles get pre-fired.
- On attack, your lurk has to create timing or flank control, not isolate you from spike.

## Map Cheat Sheet

| Map | Job |
|---|---|
| Ascent | Rendezvous for A Main/B Main early pick or Market OP timing; Trademark Cat/B Main flank depending on default. |
| Breeze | OP/value rifle angles with Rendezvous. Trademark lurk/flank because rotations are long and late lurks decide rounds. |
| Haven | Trademark Garage/flank. Rendezvous for C Long/A Long opening pick and safe anchor escape. |
| Lotus | Trap flank/door timings. Rendezvous enables A/C extremity pick and safe fall back. |
| Split | Rendezvous for Ramp/B Main pick; Trademark flank/Mid. OP angles are strong but must reposition after first shot. |
| Sunset | Trademark Mid/B flank. Rendezvous for B Main or A Main pick, then fall into retake/setup. |
| Summit | Trademark the most common wall-change flank. Rendezvous lets you test aggressive angles safely while learning the map. |

## Review Prompts

- Did I get value before dying?
- Did my utility create a timing or was it automatic?
- Did I play my role or drift into random fights?
- Did I communicate my intention before contact?
- Did I repeat a mistake from last session?
