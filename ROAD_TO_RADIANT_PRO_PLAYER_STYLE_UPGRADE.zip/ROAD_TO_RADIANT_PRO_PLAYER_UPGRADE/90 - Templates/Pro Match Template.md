# Match Template

## Info

```txt
Date:
Map:
Agent:
Score:
Result:
RR:
```

## Pre-game Focus

-

## Round Loss Patterns

| Round | Side | Cause | Correction |
|---:|---|---|---|
|  |  |  |  |

## Best Round

-

## Worst Round

-

## One Correction Next Game

-
