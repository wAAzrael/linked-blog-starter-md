# Utility Template

```txt
Map:
Agent:
Side:
Round type:
Utility:
Purpose:
Timing:
Lineup/setup:
Screenshot/clip:
Common failure:
Correction:
```
