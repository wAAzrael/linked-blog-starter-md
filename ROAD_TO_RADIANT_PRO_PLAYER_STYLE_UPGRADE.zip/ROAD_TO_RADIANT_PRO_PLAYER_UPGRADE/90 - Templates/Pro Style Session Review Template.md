%% Main template lives at [[23 - Pro Player Style Lab/Templates/Pro Style Session Review Template]] %%

# Pro Style Session Review Template

## Session Info

```txt
Date:
Rank/RR start:
Rank/RR end:
Games played:
Main agent:
Main style focus: Primmie / canezerra / Solada / Hybrid
```

## Rule Of The Session

```txt
Today I tried to:
```

## Game Log

| Game | Map | Agent | Result | Did I follow the style rule? | Main mistake |
|---|---|---|---|---|---|
| 1 |  |  |  |  |  |
| 2 |  |  |  |  |  |
| 3 |  |  |  |  |  |

## Best Round

- What happened:
- Which style principle did I use:
- Why it worked:

## Worst Round

- What happened:
- Which rule did I break:
- Correction:

## Death Categories

| Category | Count |
|---|---:|
| Panic spray |  |
| Ego peek |  |
| Bad first contact |  |
| No trade/escape |  |
| Utility unused |  |
| Overheat after kill |  |
| Bad rotation |  |

## Next Session Rule

```txt
Next session I will:
```
