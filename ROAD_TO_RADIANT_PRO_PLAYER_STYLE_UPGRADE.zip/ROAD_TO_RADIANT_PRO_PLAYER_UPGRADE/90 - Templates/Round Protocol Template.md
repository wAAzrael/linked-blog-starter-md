# Round Protocol Template

## Trigger

-

## Goal

-

## Do

-

## Do Not

-

## Comms

```txt

```

## Review

| Round | Followed? | Correction |
|---:|---|---|
|  |  |  |
