# Current Map Pool

Updated: 2026-07-04

## Competitive Pool In This Vault

- Ascent
- Breeze
- Haven
- Lotus
- Split
- Sunset
- Summit

## Archive / Not Main Ranked Pool

- Bind
- Fracture

## Summit Note

Summit is treated as a live-learning map. Do not fake exact callouts until verified in custom/VOD. Use wall-state notes and screenshots as you learn it.
