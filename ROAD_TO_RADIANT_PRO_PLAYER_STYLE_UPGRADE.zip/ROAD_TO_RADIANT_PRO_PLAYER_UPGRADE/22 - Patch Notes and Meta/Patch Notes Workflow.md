# Patch Notes Workflow

## After Every Patch

1. Check map pool changes.
2. Check agent changes for Omen, Astra, Clove, Reyna, Chamber.
3. Check weapon/economy changes.
4. Update affected map files.
5. Move outdated notes to archive instead of deleting.

## Patch Review Table

| Patch | Date | What changed | Vault files updated |
|---|---|---|---|
| 13.00 | 2026-06 | Summit enters, map pool updated | Current Map Pool, Summit |
